"""
Logging and tracing for the Q and A Agent and the Databricks App.

Two project rules are built in here:
    1. No PII in MLflow. A safety net masks NRIC, phone numbers, email addresses and card numbers in every
       span before it is saved. Users appear only as a keyed hash (HMAC), never by email.
    2. No Log Analytics. Log lines go to the console (for live debugging) and, for INFO and above, to a
       Unity Catalog table (rcm_app_log), written in small batches in the background.

Every log line carries the time in SGT, the level, the session id, the hashed user, the request id and the
trace id, so a log line can be matched to its MLflow trace.
"""
import contextvars
import hashlib
import hmac
import json
import logging
import re
import sys
import threading
import traceback
from datetime import datetime
from zoneinfo import ZoneInfo

SGT = ZoneInfo('Asia/Singapore')

# ---------------------------------------------------------------------------
# PII masking (safety net: G1 already removes PII from the question before the model sees it)
# ---------------------------------------------------------------------------
PII_PATTERNS = [
    (re.compile(r'\b[STFGM]\d{7}[A-Z]\b'), '[NRIC]'),                                   # Singapore NRIC or FIN
    (re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+'), '[EMAIL]'),                                # email address
    (re.compile(r'\b\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{4}\b'), '[CARD]'),                  # 16 digit card number
    (re.compile(r'(?:\+65[ -]?)?\b[3689]\d{3}[ -]?\d{4}\b'), '[PHONE]'),                 # Singapore phone number
]


# Replace every PII pattern in a text with a label such as [NRIC]
def mask_pii(text):
    if not isinstance(text, str):
        return text
    for pattern, label in PII_PATTERNS:
        text = pattern.sub(label, text)
    return text


# Apply mask_pii to every text inside a value (text, list or dictionary, at any depth)
def mask_value(value):
    if isinstance(value, str):
        return mask_pii(value)
    if isinstance(value, dict):
        return {k: mask_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [mask_value(v) for v in value]
    return value


# MLflow span processor: runs on every span before it is saved, and masks its inputs and outputs
def pii_span_processor(span):
    if span.inputs is not None:
        span.set_inputs(mask_value(span.inputs))
    if span.outputs is not None:
        span.set_outputs(mask_value(span.outputs))


# A keyed hash (HMAC SHA 256) of the user email. The same user always gets the same value, but the value
# cannot be turned back into the email without the key, which is kept in the secret scope
def hash_user(email, key):
    if not email or not key:
        return None
    return hmac.new(key.encode('utf-8'), email.strip().lower().encode('utf-8'), hashlib.sha256).hexdigest()[:32]


# ---------------------------------------------------------------------------
# Log context: who and what the current log lines belong to
# ---------------------------------------------------------------------------
_context = contextvars.ContextVar('rcm_log_context', default={})


# Set the session, hashed user, request and trace ids for the log lines that follow
def set_log_context(**values):
    _context.set({**_context.get(), **values})


# The current context, for one log line
def get_log_context():
    return dict(_context.get())


# Build one log row: time in SGT, level, message, context and, for an error, the stack trace (all masked)
def build_row(record, app_env):
    ctx = get_log_context()
    stack = ''.join(traceback.format_exception(*record.exc_info)) if record.exc_info else None
    return {
        'log_time_sgt': datetime.fromtimestamp(record.created, SGT).replace(tzinfo=None),
        'level': record.levelname,
        'logger': record.name,
        'message': mask_pii(record.getMessage())[:4000],
        'session_id': ctx.get('session_id'),
        'user_hash': ctx.get('user_hash'),
        'request_id': ctx.get('request_id'),
        'trace_id': ctx.get('trace_id'),
        'error_type': record.exc_info[0].__name__ if record.exc_info else None,
        'stack_trace': mask_pii(stack)[:8000] if stack else None,
        'app_env': app_env,
    }


# Console output: one JSON line per log record, so it is easy to read and to search
class JsonConsoleFormatter(logging.Formatter):
    def __init__(self, app_env):
        super().__init__()
        self.app_env = app_env

    def format(self, record):
        row = build_row(record, self.app_env)
        row['log_time_sgt'] = row['log_time_sgt'].isoformat(timespec='milliseconds')
        return json.dumps({k: v for k, v in row.items() if v is not None})


# Unity Catalog output: collects rows in memory and writes them in batches in the background,
# so the app never waits for a log write. write_rows is a function that inserts a list of rows.
class UnityCatalogLogHandler(logging.Handler):
    def __init__(self, write_rows, app_env, flush_seconds=10, batch_size=50, max_buffer=1000):
        super().__init__(level=logging.INFO)              # INFO and above go to the table
        self.write_rows, self.app_env = write_rows, app_env
        self.flush_seconds, self.batch_size, self.max_buffer = flush_seconds, batch_size, max_buffer
        self.buffer, self.buffer_lock = [], threading.Lock()
        self.flush_lock = threading.Lock()                # only one batch is written at a time
        self.stopped = threading.Event()
        threading.Thread(target=self._loop, daemon=True).start()

    # Called for every log line: the row is built now, so it keeps the context of this request
    def emit(self, record):
        try:
            row = build_row(record, self.app_env)
            with self.buffer_lock:
                if len(self.buffer) < self.max_buffer:   # if the table is down for long, drop new rows, never crash
                    self.buffer.append(row)
                full = len(self.buffer) >= self.batch_size
            if full:
                threading.Thread(target=self.flush, daemon=True).start()
        except Exception:
            self.handleError(record)

    # Write the collected rows to the table. A failure is printed and the rows are kept for the next try
    def flush(self):
        with self.flush_lock:
            with self.buffer_lock:
                rows, self.buffer = self.buffer, []
            if not rows:
                return
            try:
                self.write_rows(rows)
            except Exception as error:
                print(f'Log write to Unity Catalog failed: {type(error).__name__}', file=sys.stderr)
                with self.buffer_lock:
                    self.buffer = (rows + self.buffer)[:self.max_buffer]

    # Background loop: write the buffer every flush_seconds
    def _loop(self):
        while not self.stopped.wait(self.flush_seconds):
            self.flush()

    def close(self):
        self.stopped.set()
        self.flush()
        super().close()


# Set up the rcm logger: JSON lines to the console, and to Unity Catalog when write_rows is given
def setup_logging(app_env, write_rows=None, name='rcm'):
    logger = logging.getLogger(name)
    if getattr(logger, '_rcm_ready', False):             # the app reruns its script, so set up only once
        return logger
    logger.setLevel(logging.INFO)
    logger.propagate = False
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(JsonConsoleFormatter(app_env))
    logger.addHandler(console)
    if write_rows:
        logger.addHandler(UnityCatalogLogHandler(write_rows, app_env))
    logger._rcm_ready = True
    return logger


# ---------------------------------------------------------------------------
# Tracing
# ---------------------------------------------------------------------------
# Send traces to the MLflow experiment with this ID (never by name), mask PII in every span,
# and trace every model call made with the OpenAI client
def setup_tracing(experiment_id):
    import mlflow
    if not experiment_id:
        raise RuntimeError('MLFLOW_EXPERIMENT_ID is not set. Run notebooks/06_setup_tracing and add the ID to app.yaml')
    mlflow.set_tracking_uri('databricks')
    mlflow.set_experiment(experiment_id=experiment_id)  # fails loudly if the ID is wrong or not allowed
    mlflow.tracing.configure(span_processors=[pii_span_processor])
    mlflow.openai.autolog()
