/* =====================================================================
   12_app_documents.sql
   v_app_documents: where the stored copy of each document version is, so the app can open it
   when a user clicks a citation of the AI Assistant. Citations never go to the regulator website:
   they open this stored copy, the source of truth.
   The app looks up the file by document_id and version (both checked), never by a path from a link.
   CREATE OR REPLACE removes grants, so the grants are in this file and it runs last.
   ===================================================================== */

CREATE OR REPLACE VIEW ${catalog}.${schema}.v_app_documents AS
SELECT document_id, version, regulator_id, file_name, content_format, internal_file_path, page_count,
       content_text                -- full stored text, shown when the page text is not available
FROM ${catalog}.${schema}.rcm_doc_content
WHERE parse_status = 'PARSED';

-- The app reads the view and the files in the volume (read only)
GRANT SELECT ON TABLE ${catalog}.${schema}.v_app_documents TO `${app_service_principal}`;
GRANT READ VOLUME ON VOLUME ${catalog}.${schema}.${volume} TO `${app_service_principal}`;

-- search_chunks reads the page number, and the viewer reads the indexed text of a page, from the Gold chunk table
GRANT SELECT ON TABLE ${catalog}.${schema}.rcm_doc_chunk TO `${app_service_principal}`;
