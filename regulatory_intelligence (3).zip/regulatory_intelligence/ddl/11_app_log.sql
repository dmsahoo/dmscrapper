/* =====================================================================
   11_app_log.sql
   Application log of the Databricks App (Regulatory Scanner), in Unity Catalog.
   Log Analytics is not allowed for this project, so INFO, WARNING and ERROR lines are kept here.
   Written in small batches by common/observability.py. Holds no PII: the user is a keyed hash,
   and messages and stack traces are masked before they are written.
   Each row carries the request id and trace id, to find the matching MLflow trace.
   Runs after 10_app_grants.sql, so its grant is in this file.
   ===================================================================== */

CREATE TABLE IF NOT EXISTS ${catalog}.${schema}.rcm_app_log (
    log_time_sgt   TIMESTAMP  NOT NULL COMMENT 'When the line was logged, Singapore time',
    level          STRING     NOT NULL COMMENT 'INFO, WARNING, ERROR or CRITICAL',
    logger         STRING              COMMENT 'Name of the logger, for example rcm.app',
    message        STRING              COMMENT 'The log message, PII masked',
    session_id     STRING              COMMENT 'Random id of the browser session',
    user_hash      STRING              COMMENT 'Keyed hash (HMAC) of the user email, never the email itself',
    request_id     STRING              COMMENT 'Id of one question, also on the MLflow trace (client request id)',
    trace_id       STRING              COMMENT 'MLflow trace id',
    error_type     STRING              COMMENT 'Exception class for an error, for example TimeoutError',
    stack_trace    STRING              COMMENT 'Full stack trace for an error, PII masked',
    app_env        STRING              COMMENT 'dev, uat or prod'
)
USING DELTA
COMMENT 'Application log of the Regulatory Scanner app (no Log Analytics, no PII)';

-- The app writes and reads its own log lines
GRANT SELECT, MODIFY ON TABLE ${catalog}.${schema}.rcm_app_log TO `${app_service_principal}`;
