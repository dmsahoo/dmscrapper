# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT usage_date, sku_name, SUM(usage_quantity) AS dbus
# MAGIC FROM system.billing.usage
# MAGIC WHERE usage_date >= '2026-10-30' AND sku_name ILIKE '%SERVING%'
# MAGIC GROUP BY 1, 2
# MAGIC ORDER BY 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT usage_date, sku_name, billing_origin_product, SUM(usage_quantity) AS dbus
# MAGIC FROM system.billing.usage
# MAGIC WHERE usage_date >= '2026-10-28'
# MAGIC GROUP BY 1, 2, 3
# MAGIC ORDER BY 1 DESC, 4 DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT usage_date, workspace_id, billing_origin_product,
# MAGIC        usage_metadata.endpoint_name AS endpoint, SUM(usage_quantity) AS dbus
# MAGIC FROM system.billing.usage
# MAGIC WHERE usage_date >= '2026-10-29'
# MAGIC   AND billing_origin_product IN ('MODEL_SERVING', 'AI_FUNCTIONS', 'AI_GATEWAY')
# MAGIC GROUP BY 1, 2, 3, 4
# MAGIC ORDER BY 1 DESC, 5 DESC;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT law_or_regulation, check_problems
# MAGIC FROM externaladb.rcm_internal.rcm_doc_analysis
# MAGIC WHERE analysis_status = 'FLAGGED';

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE externaladb.rcm_internal.rcm_doc_analysis
# MAGIC ADD COLUMNS (published_date DATE COMMENT 'Publication date from the regulator website (pdf_catalog.item_date)');

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO externaladb.rcm_internal.rcm_doc_analysis t
# MAGIC USING ai_platform_dev.regulatory_scraping.pdf_catalog c
# MAGIC ON t.document_id = c.document_id
# MAGIC WHEN MATCHED THEN UPDATE SET t.published_date = c.item_date;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT law_or_regulation, published_date, date_introduced
# MAGIC FROM externaladb.rcm_internal.rcm_doc_analysis;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT size(ai_query('databricks-gte-large-en', 'test')) AS dims;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE externaladb.rcm_internal.rcm_chunk_embedding;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT regulator_id, section_title, round(score, 3) AS score, left(chunk_text, 150) AS preview
# MAGIC FROM externaladb.rcm_internal.search_chunks('What are the limits on exposures to a single counterparty group ?', 'MAS', 5);

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT regulator_id, section_title, round(score, 3) AS score, left(chunk_text, 150) AS preview
# MAGIC FROM externaladb.rcm_internal.search_chunks('FHC-N652');

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER VIEW externaladb.rcm_internal.v_app_updates AS
# MAGIC SELECT document_id, regulator_id, name_of_office, assessment_date, law_or_regulation,
# MAGIC        info_collected_date, source_url, published_date, date_introduced, effective_date,
# MAGIC        intention_background, summary_key_items, areas_of_impact, proposed_action_timeline,
# MAGIC        compliance_risk_category, importance, relevance, relevance_reason, citations, created_at_sgt
# MAGIC FROM externaladb.rcm_internal.rcm_doc_analysis
# MAGIC WHERE analysis_status = 'VALIDATED';

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT law_or_regulation, published_date FROM externaladb.rcm_internal.v_app_updates;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT law_or_regulation, change_date, importance
# MAGIC FROM externaladb.rcm_internal.get_changes(DATE'2026-10-01', DATE'2026-10-31', 'MAS');