# Databricks notebook source
# MAGIC %md
# MAGIC # 01_copy_job
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Copies clean documents from the external landing storage into the internal volume. Only files with the clean Defender verdict are copied. The fingerprint (SHA 256) is checked before and after the copy, and every copy is recorded in `rcm_promotion_log` with ingest_status PENDING, ready for parsing. Writes nothing in the external zone. |
# MAGIC | **Job and task** | Daily copy job, first task |
# MAGIC | **Parameters** | `env` (dropdown: dev, uat or prod). `regulator_id` (ALL, or one regulator such as MAS). `max_files` (empty means the value in the config). Every value is checked before use. |
# MAGIC | **Inputs** | `pdf_catalog` (external, read only), the landing blob container (read only), `config/<env>.yaml` |
# MAGIC | **Outputs** | Files in the internal volume, rows in `rcm_promotion_log` (COPIED or FAILED) |
# MAGIC | **Compute** | Serverless, or Databricks Runtime 15.4 LTS or above (Unity Catalog service credential) |
# MAGIC | **Dependencies** | ACCESS on the landing service credential, SELECT on `pdf_catalog`, MODIFY on `rcm_promotion_log`, WRITE VOLUME on the internal volume |

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Import the libraries and define the helpers
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Import the libraries, set the Singapore time zone, and define small helpers: the current time, the file fingerprint, a write that is checked by reading the file back, and a SQL call that retries briefly. |
# MAGIC | **Input** | None |
# MAGIC | **Output** | `logger`, functions `now_sgt`, `sha256_of`, `write_and_verify`, `run_sql` |

# COMMAND ----------

import hashlib
import logging
import os
import sys
import time
import uuid
from datetime import datetime
from zoneinfo import ZoneInfo

spark.conf.set('spark.sql.session.timeZone', 'Asia/Singapore')     # all SQL times in Singapore time
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger('copy_job')
SGT = ZoneInfo('Asia/Singapore')


# Current time in Singapore, without time zone, as stored in the tables
def now_sgt():
    return datetime.now(SGT).replace(tzinfo=None)


# Fingerprint (SHA 256) of the file content, checked before and after the copy
def sha256_of(data):
    return hashlib.sha256(data).hexdigest()


# Write the file, read it back and check the fingerprint. Removes the file if the check fails
def write_and_verify(path, data, expected_hash):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'wb') as f:
        f.write(data)
    with open(path, 'rb') as f:
        written = sha256_of(f.read())
    if written != expected_hash:
        os.remove(path)                                  # never leave a damaged copy behind
        raise IOError(f'Hash mismatch after writing {path}')
    return written


# Run a SQL statement with parameters, retrying briefly if another job is writing the same table
def run_sql(sql, args, attempts=3):
    for i in range(1, attempts + 1):
        try:
            return spark.sql(sql, args=args)
        except Exception:
            if i == attempts:
                raise                                    # give up after the last attempt
            time.sleep(3 * i)                            # wait 3, then 6 seconds

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Load the settings and read the parameters
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Load the config for the chosen environment and read every name from it. Read and check the widgets: `regulator_id` must be ALL or a code such as MAS, and `max_files` must be a whole number from 1 to 1000. |
# MAGIC | **Input** | Widgets `env`, `regulator_id`, `max_files`; file `config/<env>.yaml` |
# MAGIC | **Output** | Table and storage names, `REGULATOR_ID`, `MAX_FILES`, `RUN_ID` |

# COMMAND ----------

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

from common.config import load_config, table, external_table, volume_path
from common.widgets import env_widget, int_widget, regulator_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
print('Settings from', CFG['_path'])

# Names and limits, all from the config file
PDF_CATALOG = external_table(CFG, 'pdf_catalog')                          # external, read only
LANDING_ACCOUNT = CFG['landing']['storage_account']                       # external landing blob storage, read only
LANDING_CONTAINER = CFG['landing']['container']
LANDING_PREFIX = CFG['landing']['prefix']
SERVICE_CREDENTIAL = CFG['landing']['service_credential']                 # internal workspace managed identity (read access)
TARGET_ROOT = volume_path(CFG)                                            # internal volume
PROMOTION_LOG = table(CFG, 'rcm_promotion_log')                           # internal table
CLEAN_VALUE = CFG['landing']['clean_verdict']                             # Defender verdict that allows a copy
MAX_RETRIES = CFG['copy']['max_retries']                                  # a file that failed this often is not tried again

# Parameters, checked before use. An empty max_files uses the value in the config
REGULATOR_ID = regulator_widget(dbutils)                                  # ALL, or one regulator such as MAS
MAX_FILES = int_widget(dbutils, 'max_files', CFG['copy']['max_files'], 1, 1000)   # checked whole number, safe in LIMIT
REG_FILTER = '' if REGULATOR_ID == 'ALL' else 'AND c.regulator_id = :regulator_id'   # the value itself is a parameter

# One id for this run, for example copy_20261119_093000_ab12cd
RUN_ID = 'copy_' + now_sgt().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6]
logger.info('Run %s | regulator %s | max files %s', RUN_ID, REGULATOR_ID, MAX_FILES)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Build the work list
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Find the clean files whose current version is not copied yet, plus earlier failures that have not reached the retry limit. All values are passed as SQL parameters. |
# MAGIC | **Input** | `pdf_catalog`, `rcm_promotion_log` |
# MAGIC | **Output** | `todo` (the files to copy, oldest change first) |

# COMMAND ----------

todo = spark.sql(f'''
    SELECT c.document_id, c.current_version AS version, c.regulator_id, c.category_id,
           c.content_format, c.file_name, c.source_url, c.raw_file_path,
           c.content_hash_sha256, c.malware_scan_verdict,
           coalesce(p.copy_retry_count, 0) AS copy_retry_count
    FROM {PDF_CATALOG} c
    LEFT JOIN {PROMOTION_LOG} p
      ON p.document_id = c.document_id AND p.version = c.current_version
    WHERE c.malware_scan_verdict = :clean
      AND (p.document_id IS NULL OR (p.copy_status = 'FAILED' AND p.copy_retry_count < :max_retries))
      {REG_FILTER}
    ORDER BY c.last_changed_sgt
    LIMIT {MAX_FILES}
''', args={'clean': CLEAN_VALUE, 'max_retries': MAX_RETRIES,
           **({} if REGULATOR_ID == 'ALL' else {'regulator_id': REGULATOR_ID})}).collect()
logger.info('Copy run %s: %s files to copy', RUN_ID, len(todo))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Define the copy and the record of each copy
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Connect to the landing container with the managed identity (no keys). Define how one file is copied safely (only from the expected folder, fingerprint checked), and how its result is saved in `rcm_promotion_log`. |
# MAGIC | **Input** | Landing service credential, `LANDING_PREFIX`, `TARGET_ROOT` |
# MAGIC | **Output** | `landing` (container client), functions `copy_one` and `record` |

# COMMAND ----------

from azure.storage.blob import BlobServiceClient

# Insert or update one row per document version. Every value is a parameter (:name)
UPSERT = f'''
    MERGE INTO {PROMOTION_LOG} t
    USING (SELECT :document_id AS document_id, :version AS version) s
    ON t.document_id = s.document_id AND t.version = s.version
    WHEN MATCHED THEN UPDATE SET
        copy_status = :status, copy_retry_count = :retries, copy_error_details = :error,
        internal_file_path = :target, content_hash_sha256 = :hash, copied_at_sgt = :copied_at,
        ingest_status = :ingest_status, run_id = :run_id, updated_at_sgt = :now
    WHEN NOT MATCHED THEN INSERT (
        document_id, version, regulator_id, category_id, content_format, file_name, source_url,
        raw_file_path, internal_file_path, content_hash_sha256, malware_scan_verdict, copy_status,
        copy_retry_count, copy_error_details, copied_at_sgt, ingest_status, run_id, updated_at_sgt)
    VALUES (
        :document_id, :version, :regulator_id, :category_id, :content_format, :file_name, :source_url,
        :raw_file_path, :target, :hash, :verdict, :status,
        :retries, :error, :copied_at, :ingest_status, :run_id, :now)
'''


# Save the result of one copy (COPIED or FAILED) in rcm_promotion_log
def record(row, status, target=None, hash_=None, error=None):
    copied = status == 'COPIED'
    args = {
        'document_id': row['document_id'], 'version': row['version'], 'regulator_id': row['regulator_id'],
        'category_id': row['category_id'], 'content_format': row['content_format'],
        'file_name': row['file_name'], 'source_url': row['source_url'], 'raw_file_path': row['raw_file_path'],
        'verdict': row['malware_scan_verdict'], 'status': status,
        'retries': row['copy_retry_count'] + (0 if copied else 1),       # a failure counts as one more attempt
        'error': error, 'target': target, 'hash': hash_,
        'copied_at': now_sgt() if copied else None,
        'ingest_status': 'PENDING' if copied else None,                    # PENDING tells the parse job to pick it up
        'run_id': RUN_ID, 'now': now_sgt(),
    }
    run_sql(UPSERT, args)


# Read only connection to the landing container, signed in with the managed identity
landing = (BlobServiceClient(f'https://{LANDING_ACCOUNT}.blob.core.windows.net',
                             credential=dbutils.credentials.getServiceCredentialsProvider(SERVICE_CREDENTIAL))
           .get_container_client(LANDING_CONTAINER))


# Copy one clean file: download from the landing blob, check the fingerprint, write it and verify it
def copy_one(row):
    blob_name = row['raw_file_path']                                       # blob name in the landing container
    if not blob_name.startswith(LANDING_PREFIX + '/') or '..' in blob_name:
        raise ValueError(f'Unsafe or unexpected blob name: {blob_name}')   # only files under the expected folder
    target = TARGET_ROOT + blob_name[len(LANDING_PREFIX):]
    data = landing.download_blob(blob_name).readall()
    source_hash = sha256_of(data)
    # For PDFs, pdf_catalog holds the hash of the file, so the source must match it.
    # For HTML snapshots, pdf_catalog holds a fingerprint of the page text (used by the scraper
    # to detect real content changes), not of the file, so only the copy itself is verified.
    if row['content_format'] == 'PDF' and source_hash != row['content_hash_sha256']:
        raise ValueError('Source hash does not match pdf_catalog')
    return target, write_and_verify(target, data, source_hash)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5: Copy the files
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Copy each file in the work list and record the result. One failed file does not stop the others: it is recorded as FAILED and tried again in the next run. |
# MAGIC | **Input** | `todo` |
# MAGIC | **Output** | Files in the internal volume, rows in `rcm_promotion_log`, counts `copied` and `failed` |

# COMMAND ----------

copied = failed = 0
for i, row in enumerate(todo, start=1):
    try:
        target, target_hash = copy_one(row)
        record(row, 'COPIED', target=target, hash_=target_hash)
        copied += 1
        logger.info('[%s of %s] COPIED %s v%s', i, len(todo), row['file_name'], row['version'])
    except Exception as error:
        failed += 1
        logger.error('[%s of %s] FAILED %s: %s', i, len(todo), row['file_name'], error)
        try:
            record(row, 'FAILED', error=f'{type(error).__name__}: {error}'[:4000])   # keep the error short
        except Exception as log_error:
            logger.error('Could not record the failure: %s', log_error)

logger.info('Copy run %s: %s copied, %s failed', RUN_ID, copied, failed)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 6: Finish the run
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Fail the job run if any file failed, so the failure is visible in the job history and alerts. Otherwise end with a short summary. |
# MAGIC | **Input** | Counts `copied` and `failed` |
# MAGIC | **Output** | Job run status (failed or succeeded) and the exit message |

# COMMAND ----------

if failed:
    raise RuntimeError(f'Copy run {RUN_ID}: {failed} files failed. See rcm_promotion_log where copy_status = FAILED.')
dbutils.notebook.exit(f'{RUN_ID} copied={copied} failed={failed}')
