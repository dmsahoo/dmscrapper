# Databricks notebook source
# MAGIC %md
# MAGIC # 04_embed_chunks
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Adds an embedding (a list of numbers that captures the meaning of the text) for every new chunk in `rcm_doc_chunk`, and removes the embeddings of chunks that no longer exist. The search tool of the Q and A Agent reads this table. |
# MAGIC | **Job and task** | Daily ingest job, after the parse task |
# MAGIC | **Parameters** | `env` (dropdown: dev, uat or prod). Checked before use. |
# MAGIC | **Inputs** | `rcm_doc_chunk` (Gold), `pdf_catalog` (external, read only, for the published date), the embedding model, `config/<env>.yaml` |
# MAGIC | **Outputs** | Rows in `rcm_chunk_embedding` |
# MAGIC | **Compute** | Serverless |
# MAGIC | **Dependencies** | Access to the embedding model through `ai_query`, SELECT on the input tables, MODIFY on `rcm_chunk_embedding` |

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Load the settings
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Load the config for the chosen environment and read the table names and the embedding model. |
# MAGIC | **Input** | Widget `env`, file `config/<env>.yaml` |
# MAGIC | **Output** | `CHUNK_TABLE`, `EMBEDDING_TABLE`, `PDF_CATALOG`, `EMBEDDING_MODEL` |

# COMMAND ----------

import os
import sys

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

from common.config import load_config, table, external_table
from common.widgets import env_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
print('Settings from', CFG['_path'])

# Names, all from the config file
CHUNK_TABLE = table(CFG, 'rcm_doc_chunk')                # Gold: chunks of the current version
EMBEDDING_TABLE = table(CFG, 'rcm_chunk_embedding')      # one embedding per chunk
PDF_CATALOG = external_table(CFG, 'pdf_catalog')         # external, read only
EMBEDDING_MODEL = CFG['embedding_model']                 # for example databricks-gte-large-en

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Add the embeddings of new chunks
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Create an embedding only for chunks that do not have one yet, so a rerun does not pay for the same chunk twice. The published date is added from `pdf_catalog`, so the agent can filter by date. The model name is passed as the SQL parameter `:model`. |
# MAGIC | **Input** | `rcm_doc_chunk`, `pdf_catalog`, `rcm_chunk_embedding`, `EMBEDDING_MODEL` |
# MAGIC | **Output** | New rows in `rcm_chunk_embedding` |

# COMMAND ----------

spark.sql(f'''
    INSERT INTO {EMBEDDING_TABLE}
    SELECT c.chunk_id, c.document_id, c.version, c.regulator_id, c.section_title, c.chunk_text,
           p.item_date, c.source_url,
           ai_query(:model, c.chunk_text),
           from_utc_timestamp(current_timestamp(), 'Asia/Singapore')
    FROM {CHUNK_TABLE} c
    LEFT JOIN {PDF_CATALOG} p ON p.document_id = c.document_id
    LEFT ANTI JOIN {EMBEDDING_TABLE} e ON e.chunk_id = c.chunk_id
''', args={'model': EMBEDDING_MODEL})

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Remove the embeddings of old chunks
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Delete the embeddings of chunks that are no longer in Gold, for example the chunks of an old version replaced by a new one, so the search never returns outdated text. |
# MAGIC | **Input** | `rcm_doc_chunk`, `rcm_chunk_embedding` |
# MAGIC | **Output** | Old rows removed from `rcm_chunk_embedding` |

# COMMAND ----------

spark.sql(f'''
    DELETE FROM {EMBEDDING_TABLE}
    WHERE chunk_id NOT IN (SELECT chunk_id FROM {CHUNK_TABLE})
''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Check the result
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Show the number of embeddings, the embedding size (1024 for databricks-gte-large-en) and how many chunks have a published date. |
# MAGIC | **Input** | `rcm_chunk_embedding` |
# MAGIC | **Output** | A one row summary in the notebook output |

# COMMAND ----------

display(spark.sql(f'''
    SELECT COUNT(*) AS chunks, MIN(size(embedding)) AS dims, COUNT(published_date) AS with_date
    FROM {EMBEDDING_TABLE}
'''))
