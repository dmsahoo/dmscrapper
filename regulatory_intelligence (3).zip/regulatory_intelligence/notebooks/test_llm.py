# Databricks notebook source
# Install the Databricks OpenAI client (it signs in to Databricks automatically)
%pip install databricks-openai --quiet
dbutils.library.restartPython()

# COMMAND ----------

# Get the workspace address and a sign in token from the notebook's own identity (no stored secrets)
from databricks.sdk import WorkspaceClient
from openai import OpenAI
w = WorkspaceClient()
token = w.config.authenticate()['Authorization'].split(' ')[1]

# Create a client that talks to the Unity AI Gateway, where our model service lives
client = OpenAI(base_url=f'{w.config.host}/ai-gateway/mlflow/v1', api_key=token)

# Send a short test message to our model service
response = client.chat.completions.create(
    model='externaladb.rcm_internal.rcm_llm_dev',
    messages=[{'role': 'user', 'content': 'Reply only with JSON: {"status": "ok"}'}],
    max_tokens=50,
)

# Print the answer: it should be the JSON
print(response.choices[0].message.content)