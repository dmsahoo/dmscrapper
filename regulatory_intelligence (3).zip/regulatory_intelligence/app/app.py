"""
Regulatory Scanner (C11): Streamlit app on Databricks Apps.

Tab 1, Latest changes: the CPDAP CPL results from the Regulator Agent, with filters,
a table, and the full summary of the selected item. Read only.
One row per document (its newest version). Each row is labelled New (first version) or
Updated (a newer copy at the same link). For an update, the detail panel shows what changed,
the exact wording changes, and the previous versions.
Tab 2, AI Assistant: questions answered by the Q and A Agent (agents/qa_agent.py), with
guardrails G1 and G2 (guardrails/guardrails.py). Answers come only from the regulatory documents.

The app is deployed from the repository root (app.yaml there), so it can use the shared
agents, guardrails, prompts and config folders.

Observability (common/observability.py): every question is one MLflow trace in the experiment given by
MLFLOW_EXPERIMENT_ID, with no PII. Log lines go to the console and to the Unity Catalog table rcm_app_log
(no Log Analytics). The session id, hashed user, request id and trace id link a log line to its trace.
"""
import json
import os
import re
import sys
import uuid
from datetime import date

import pandas as pd
import streamlit as st
from databricks import sql
from databricks.sdk.core import Config

st.set_page_config(page_title='Regulatory Scanner', layout='wide')

# Make the repository folders importable (app.py lives in the app folder)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)
from agents.qa_agent import QAAgent                                    # noqa: E402
from common.config import load_config, table, volume_path             # noqa: E402
from common.observability import hash_user, set_log_context, setup_logging, setup_tracing   # noqa: E402
from guardrails.guardrails import Guardrails                           # noqa: E402

# Settings: names come from config/<env>.yaml, where env is RCM_ENV in app.yaml (nothing is hardcoded).
# The SQL warehouse comes from the app's sql-warehouse resource, also set in app.yaml.
CFG = load_config(os.getenv('RCM_ENV'))
WAREHOUSE_ID = os.getenv('DATABRICKS_WAREHOUSE_ID')
VIEW = table(CFG, 'v_app_updates')                                     # one row per document, newest version
HISTORY_VIEW = table(CFG, 'v_app_history')                             # every version, for Previous versions
DIFF_TABLE = table(CFG, 'rcm_doc_diff')                                # exact wording changes between versions
MODEL = CFG['model_service']
APP_ENV = CFG['environment']                                           # dev, uat or prod, on every log line and trace
LOG_TABLE = table(CFG, 'rcm_app_log')                                  # application log in Unity Catalog
DOCS_VIEW = table(CFG, 'v_app_documents')                              # where the stored copy of each document is
CHUNK_TABLE = table(CFG, 'rcm_doc_chunk')                              # the indexed text of each page (Gold)
VOLUME_ROOT = volume_path(CFG)                                         # stored documents are only read from here
DOC_ID_PATTERN = re.compile(r'^[0-9a-f]{64}$')                         # document ids are SHA 256 fingerprints
LOG_COLUMNS = ['log_time_sgt', 'level', 'logger', 'message', 'session_id', 'user_hash', 'request_id',
               'trace_id', 'error_type', 'stack_trace', 'app_env']

# Example questions shown next to the chat (change them to match the regulators that are loaded)
EXAMPLE_QUESTIONS = ['What changed for MAS in October 2026 ?',
                     'What does MAS Notice 656 say about limits on exposures to a single counterparty group ?',
                     'What is the effective date of the MAS Notice FHC-N652 amendment ?']

# How the agent's relevance values are shown on screen
RELEVANCE_LABEL = {'RELEVANT': 'Potentially Relevant', 'NOT_RELEVANT': 'Not Relevant',
                   'EXCLUDED': 'Not Relevant'}

# Cell colours for importance and relevance, like the design
COLOURS = {'High': '#FDE8E8', 'Medium': '#FEF3C7', 'Low': '#E8F1FD', 'Pending Review': '#F3F4F6',
           'Potentially Relevant': '#E7F6EC', 'Not Relevant': '#F3F4F6',
           'New': '#E7F6EC'}                                             # Updated rows get the amber colour below
UPDATED_COLOUR = '#FEF3C7'

# How each kind of difference is shown in the Exact wording changes list
CHANGE_KIND_LABEL = {'ADDED': 'Added', 'REMOVED': 'Removed', 'CHANGED': 'Changed'}


# Read the view through the SQL warehouse, signing in as the app's own identity.
# Results are kept for 5 minutes so the page stays fast.
@st.cache_data(ttl=300)
def load_updates():
    cfg = Config()
    with sql.connect(server_hostname=cfg.host,
                     http_path=f'/sql/1.0/warehouses/{WAREHOUSE_ID}',
                     credentials_provider=lambda: cfg.authenticate) as conn:
        with conn.cursor() as cur:
            cur.execute(f'SELECT * FROM {VIEW} ORDER BY info_collected_date DESC, law_or_regulation')
            df = cur.fetchall_arrow().to_pandas()
    df['relevance_label'] = df['relevance'].map(RELEVANCE_LABEL).fillna('Pending Review')
    # The sticker shown in the table: New, or Updated with its version number (for example Updated (v2))
    df['change_label'] = [f'Updated (v{v})' if c == 'UPDATED' else 'New'
                          for c, v in zip(df['change_type'], df['version'])]
    return df


# Write a batch of log rows to rcm_app_log. Called in the background by the log handler, never by a page.
# Every value is a parameter, never pasted into the SQL
def write_log_rows(rows):
    cfg = Config()
    statement = (f"INSERT INTO {LOG_TABLE} ({', '.join(LOG_COLUMNS)}) "
                 f"VALUES ({', '.join(':' + c for c in LOG_COLUMNS)})")
    with sql.connect(server_hostname=cfg.host,
                     http_path=f'/sql/1.0/warehouses/{WAREHOUSE_ID}',
                     credentials_provider=lambda: cfg.authenticate) as conn:
        with conn.cursor() as cur:
            cur.executemany(statement, [{c: r.get(c) for c in LOG_COLUMNS} for r in rows])


# Set up logging and tracing once for the whole app (the page script reruns, this does not)
@st.cache_resource
def init_observability():
    log = setup_logging(APP_ENV, write_rows=write_log_rows, name='rcm.app')
    setup_tracing(os.getenv('MLFLOW_EXPERIMENT_ID'))                   # stops with a clear error if the ID is missing
    log.info('App started, traces go to experiment %s', os.getenv('MLFLOW_EXPERIMENT_ID'))
    return log


try:
    logger = init_observability()
except Exception as error:                                             # show the reason, do not run without tracing
    st.error(f'The app could not start its tracing: {error}')
    st.stop()


# Run a small query with parameters through the SQL warehouse (values are passed safely, never pasted in)
def run_query(statement, params):
    cfg = Config()
    with sql.connect(server_hostname=cfg.host,
                     http_path=f'/sql/1.0/warehouses/{WAREHOUSE_ID}',
                     credentials_provider=lambda: cfg.authenticate) as conn:
        with conn.cursor() as cur:
            cur.execute(statement, params)
            return cur.fetchall_arrow().to_pandas()


# Every validated version of one document, newest first (for the Previous versions list)
@st.cache_data(ttl=300)
def load_history(document_id):
    return run_query('SELECT version, change_type, law_or_regulation, info_collected_date, published_date, '
                     f'effective_date, source_url FROM {HISTORY_VIEW} '
                     'WHERE document_id = :doc ORDER BY version DESC', {'doc': document_id})


# The exact wording changes between this version and the previous one (found by code, not AI)
@st.cache_data(ttl=300)
def load_diff(document_id, version):
    return run_query(f'SELECT change_no, change_kind, old_text, new_text FROM {DIFF_TABLE} '
                     'WHERE document_id = :doc AND version = :ver ORDER BY change_no',
                     {'doc': document_id, 'ver': int(version)})


# Create the Q and A Agent once and reuse it. The guardrails use keys from the app's secret resources,
# because the app's service principal cannot use the managed identity
@st.cache_resource
def get_agent():
    gc = CFG['guardrails']                                              # guardrail endpoints and limits from the config
    guard = Guardrails(gc['content_safety_endpoint'], gc['language_endpoint'],
                       content_safety_key=os.getenv('CONTENT_SAFETY_KEY'),   # keys only from the secret resources
                       language_key=os.getenv('LANGUAGE_KEY'),
                       block_severity=gc['block_severity'], timeout_seconds=gc['timeout_seconds'])
    with open(os.path.join(ROOT, 'prompts', 'qa_prompt.md')) as f:
        prompt = f.read()
    return QAAgent(warehouse_id=WAREHOUSE_ID, model=MODEL, guard=guard, prompt_template=prompt,
                   functions=f"{CFG['catalog']}.{CFG['schema']}",
                   search_top_k=CFG['agent']['search_top_k'],
                   max_tool_rounds=CFG['agent']['qa_max_tool_rounds'],
                   max_output_tokens=CFG['agent']['qa_max_output_tokens'],
                   environment=APP_ENV)


# Build the 12 CPDAP CPL fields in Law Tracker order, for the copy boxes
def law_tracker_fields(r):
    field4 = f"{r['info_collected_date']}; {r['source_url']}"
    return [
        ('Name of Office', r['name_of_office']),
        ('Assessment Date', r['assessment_date']),
        ('Law / Regulation', r['law_or_regulation']),
        ('Date information collected and source', field4),
        ('Date Introduced', r['date_introduced']),
        ('Effective Date', r['effective_date']),
        ('Intention / Background of change', r['intention_background']),
        ('Summary of Key items', r['summary_key_items']),
        ('Areas of Impact for the bank', r['areas_of_impact']),
        ('Proposed Action to be taken and estimated timeline', r['proposed_action_timeline']),
        ('Compliance Risk Category', r['compliance_risk_category']),
        ('Importance', r['importance']),
    ]


# One tab separated row for pasting into Excel (line breaks inside a field become semicolons)
def excel_row(r):
    return '\t'.join(str(v or '').replace('\r', ' ').replace('\n', '; ') for _, v in law_tracker_fields(r))


# Readable text for pasting into an email
def email_text(r):
    return '\n'.join(f'{name}: {value or ""}' for name, value in law_tracker_fields(r))


# Colour the importance and relevance cells
def colour_cells(value):
    if str(value).startswith('Updated'):
        return f'background-color: {UPDATED_COLOUR}'
    return f'background-color: {COLOURS[value]}' if value in COLOURS else ''


# ---------------------------------------------------------------------------
# Header: title, last updated time and the signed in user
# ---------------------------------------------------------------------------
df = load_updates()
user = st.context.headers.get('X-Forwarded-Email', 'CPDAP CPL User')

# Ids for logs and traces. The session id is random. The user is a keyed hash of the email (the key is in
# the secret scope), so the email itself never reaches MLflow or the log table
SESSION_ID = st.session_state.setdefault('session_id', uuid.uuid4().hex)
USER_HASH = hash_user(st.context.headers.get('X-Forwarded-Email'), os.getenv('USER_HASH_KEY'))
set_log_context(session_id=SESSION_ID, user_hash=USER_HASH, request_id=None, trace_id=None)


# ---------------------------------------------------------------------------
# Document viewer: a citation of the AI Assistant opens the stored copy of the document from our volume,
# never the regulator website. A citation link looks like ?doc=<document_id>&v=<version>&page=<page>
# ---------------------------------------------------------------------------
# Read a stored file from the volume (cached, so moving between pages does not download it again)
@st.cache_data(ttl=600, max_entries=20, show_spinner=False)
def load_stored_file(path):
    from databricks.sdk import WorkspaceClient
    return WorkspaceClient().files.download(path).contents.read()


# The indexed text of one document version, page by page: exactly the text the Q and A Agent searched.
# Uses only the libraries the app already has (no PDF library is needed)
@st.cache_data(ttl=600, max_entries=50, show_spinner=False)
def load_indexed_pages(doc, version):
    return run_query(f'SELECT page_number, section_title, chunk_text FROM {CHUNK_TABLE} '
                     f'WHERE document_id = :doc AND version = :ver ORDER BY chunk_index',
                     {'doc': doc, 'ver': version})


# Show the stored document of a citation link. Every value from the link is checked first, and the file path
# comes from v_app_documents, never from the link, so a link cannot point to another file
def show_document(params):
    doc = str(params.get('doc', '')).strip().lower()
    version, page = str(params.get('v', '')), str(params.get('page', '1'))
    if not DOC_ID_PATTERN.match(doc) or not version.isdigit() or not page.isdigit():
        st.error('This document link is not valid.')
        return
    rows = run_query(f'SELECT file_name, content_format, internal_file_path, page_count, content_text '
                     f'FROM {DOCS_VIEW} WHERE document_id = :doc AND version = :ver',
                     {'doc': doc, 'ver': int(version)})
    if rows.empty:
        st.error('This document version is not available.')
        return
    r = rows.iloc[0]
    path = str(r['internal_file_path'])
    if not path.startswith(VOLUME_ROOT + '/') or '..' in path:          # only files in our own volume
        logger.warning('Document path outside the volume refused for %s', doc[:12])
        st.error('This document cannot be opened.')
        return
    logger.info('Stored document opened: %s version %s page %s', doc[:12], version, page)

    st.title(r['file_name'])
    st.caption(f'Stored copy in the Regulatory Scanner, version {version}. This copy is the source of truth.')
    # The original stored file, opened by the browser's own PDF viewer after download
    st.download_button('Download the stored document', load_stored_file(path), file_name=r['file_name'],
                       mime='application/pdf' if r['content_format'] == 'PDF' else 'text/html')

    # The indexed text of the cited page, the same text the answer was based on
    chunks = load_indexed_pages(doc, int(version))
    pages = sorted({int(p) for p in chunks['page_number'].dropna()}) if not chunks.empty else []
    if pages:
        cited = int(page) if int(page) in pages else pages[0]
        page_no = st.selectbox('Page', pages, index=pages.index(cited))
        st.subheader(f'Page {page_no}' + ('  (cited page)' if page_no == int(page) else ''))
        for _, c in chunks[chunks['page_number'] == page_no].iterrows():
            if c['section_title']:
                st.markdown(f"**{c['section_title']}**")
            st.text(c['chunk_text'])
    else:
        # No page numbers (HTML snapshot, or an older version no longer indexed): show the full stored text
        st.text(r['content_text'] or 'No text stored for this document version.')


# A citation link opens this app in a new tab with ?doc=...: show only that document, not the main page
if 'doc' in st.query_params:
    show_document(st.query_params)
    st.stop()
left, right = st.columns([3, 1])
left.title('Regulatory Scanner')
last = df['created_at_sgt'].max() if not df.empty else None
right.caption(f"Last updated: {last:%d %b %Y, %H:%M} SGT" if last is not None else 'No results yet')
right.caption(f'Signed in as {user}')

tab_changes, tab_assistant = st.tabs(['Latest changes', 'AI Assistant'])

# ---------------------------------------------------------------------------
# Tab 1: Latest changes
# ---------------------------------------------------------------------------
with tab_changes:
    # Filters (Clear filters resets them all)
    if st.session_state.get('clear'):
        for key in ['search', 'regulator', 'change', 'category', 'importance', 'relevance', 'dates']:
            st.session_state.pop(key, None)
        st.session_state['clear'] = False

    f1, f2, f2b, f3, f4, f5, f6, f7 = st.columns([2.6, 1.2, 1.2, 1.7, 1.2, 1.6, 2.1, 1])
    search = f1.text_input('Search', placeholder='Search title, regulator or keyword', key='search')
    regulator = f2.selectbox('Regulator', ['All'] + sorted(df['regulator_id'].dropna().unique()), key='regulator')
    change = f2b.selectbox('Change', ['All', 'New', 'Updated'], key='change')        # New or Updated documents
    category = f3.selectbox('Compliance risk category',
                            ['All'] + sorted(df['compliance_risk_category'].dropna().unique()), key='category')
    importance = f4.selectbox('Importance', ['All', 'High', 'Medium', 'Low', 'Pending Review'], key='importance')
    relevance = f5.selectbox('Relevance', ['All', 'Potentially Relevant', 'Not Relevant'], key='relevance')
    collected = pd.to_datetime(df['info_collected_date'])
    min_d = collected.min().date() if collected.notna().any() else date.today()
    max_d = collected.max().date() if collected.notna().any() else date.today()
    dates = f6.date_input('Date collected', value=(min_d, max_d), key='dates')
    f7.write('')
    f7.button('Clear filters', on_click=lambda: st.session_state.update(clear=True))

    # Apply the filters
    view = df.copy()
    if search:
        text = (view['law_or_regulation'].fillna('') + ' ' + view['regulator_id'].fillna('') + ' '
                + view['summary_key_items'].fillna(''))
        view = view[text.str.contains(search, case=False, regex=False)]
    if regulator != 'All':
        view = view[view['regulator_id'] == regulator]
    if change != 'All':
        view = view[view['change_type'] == change.upper()]
    if category != 'All':
        view = view[view['compliance_risk_category'] == category]
    if importance != 'All':
        view = view[view['importance'] == importance]
    if relevance != 'All':
        view = view[view['relevance_label'] == relevance]
    if isinstance(dates, tuple) and len(dates) == 2:
        d = pd.to_datetime(view['info_collected_date'])
        view = view[(d >= pd.Timestamp(dates[0])) & (d <= pd.Timestamp(dates[1]))]

    # Table, one page at a time
    p1, p2, p3 = st.columns([6, 1, 1])
    page_size = p3.selectbox('Show per page', [5, 10, 20], index=0)
    pages = max(1, -(-len(view) // page_size))
    page = p2.number_input('Page', min_value=1, max_value=pages, value=1)
    p1.caption(f'Showing {min(len(view), (page - 1) * page_size + 1)} to '
               f'{min(len(view), page * page_size)} of {len(view)} results')
    page_df = view.iloc[(page - 1) * page_size: page * page_size].reset_index(drop=True)

    table = page_df[['info_collected_date', 'law_or_regulation', 'regulator_id', 'event_type', 'change_label',
                     'date_introduced', 'compliance_risk_category', 'importance', 'relevance_label']].rename(columns={
        'info_collected_date': 'Date collected', 'law_or_regulation': 'Title / Publication',
        'regulator_id': 'Regulator', 'event_type': 'Type', 'change_label': 'Change',
        'date_introduced': 'Date introduced', 'compliance_risk_category': 'Compliance risk category',
        'importance': 'Importance', 'relevance_label': 'Relevance'})
    styled = table.style.map(colour_cells, subset=['Change', 'Importance', 'Relevance'])
    selection = st.dataframe(styled, hide_index=True, use_container_width=True,
                             on_select='rerun', selection_mode='single-row')

    # Detail panel for the selected row (the first row if nothing is selected)
    rows = selection.selection.rows if selection else []
    if page_df.empty:
        st.info('No results match the filters.')
    else:
        r = page_df.iloc[rows[0] if rows else 0]
        st.divider()
        h1, h2, h3, h4 = st.columns([4, 1.3, 1.3, 1.2])
        h1.subheader(r['law_or_regulation'])
        # Under the title: is this a new document, or an update of an earlier version ?
        if r['change_type'] == 'UPDATED':
            prev = int(r['previous_version']) if pd.notna(r['previous_version']) else int(r['version']) - 1
            h1.caption(f"Updated: version {int(r['version'])}, compared with version {prev} · {r['event_type']}")
        else:
            h1.caption(f"New document · {r['event_type']}")
        with h2.popover('Copy for Excel (12 fields)'):
            st.caption('Click the copy icon, then paste into the Law Tracker row.')
            st.code(excel_row(r), language=None)
        with h3.popover('Copy for Email (formatted)'):
            st.code(email_text(r), language=None)
        h4.link_button('Open original source', r['source_url'] or '#')

        c1, c2, c3 = st.columns([1.1, 1.6, 1.3])
        # Left: the field list
        with c1:
            fields = [('Name of office', r['name_of_office']),
                      ('Law / regulation', r['law_or_regulation']),
                      ('Date information collected', r['info_collected_date']),
                      ('Source', f"[Open source]({r['source_url']})"),
                      ('Date introduced', r['date_introduced']),
                      ('Effective date', r['effective_date']),
                      ('Compliance risk category', r['compliance_risk_category']),
                      ('Importance', r['importance'])]
            st.markdown('\n'.join(f'**{k}**  \n{v}\n' for k, v in fields))
        # Middle: relevance, rationale, background and key items
        with c2:
            # For an update, show what changed first, because that is what compliance needs to see
            if r['change_type'] == 'UPDATED':
                st.markdown('**What changed since the previous version**')
                st.info(r['what_changed'] or 'Not available for this record.')
                diff = load_diff(r['document_id'], r['version'])
                with st.expander(f'Exact wording changes ({len(diff)})'):
                    st.caption('Found by comparing the full text of the two versions (code, not AI).')
                    for _, d in diff.iterrows():
                        st.markdown(f"**{d['change_no']}. {CHANGE_KIND_LABEL.get(d['change_kind'], d['change_kind'])}**")
                        if d['old_text']:
                            st.markdown(f"Old: {d['old_text']}")
                        if d['new_text']:
                            st.markdown(f"New: {d['new_text']}")
            st.markdown(f"**AI Relevance Assessment:** {r['relevance_label']}")
            st.markdown('**AI rationale**')
            st.write(r['relevance_reason'])
            st.markdown('**Intention / Background of change**')
            st.write(r['intention_background'])
            st.markdown('**Summary of Key items**')
            st.markdown(r['summary_key_items'] or '')
        # Right: impact, proposed action and supporting sources
        with c3:
            st.markdown('**Areas of impact for the bank**')
            st.write(r['areas_of_impact'])
            st.markdown('**Proposed action to be taken and estimated timeline**')
            st.write(r['proposed_action_timeline'])
            # Every earlier version of this document, so users can see its history
            if r['change_type'] == 'UPDATED':
                with st.expander('Previous versions'):
                    for _, h in load_history(r['document_id']).iterrows():
                        if h['version'] != r['version']:
                            st.markdown(f"Version {h['version']}: collected {h['info_collected_date']}, "
                                        f"effective {h['effective_date'] or 'Not Stated'}")
            with st.expander('Supporting source information'):
                cites = list(r['citations']) if r['citations'] is not None else []
                st.write(f'{len(cites)} supporting passages from the source document.')
                st.markdown(f"[Open original source]({r['source_url']})")

        st.caption('Draft assessment generated by AI. Subject to CPDAP CPL and SME confirmation. Not legal advice.')

# ---------------------------------------------------------------------------
# Tab 2: AI Assistant
# ---------------------------------------------------------------------------
with tab_assistant:
    a1, a2 = st.columns([1, 3])
    # Left: example questions (click to ask) and a button to start again
    with a1:
        st.markdown('**Example questions**')
        for i, q in enumerate(EXAMPLE_QUESTIONS):
            if st.button(q, key=f'example_{i}', use_container_width=True):
                st.session_state['pending_question'] = q
        if st.button('Clear chat', key='clear_chat'):
            st.session_state['messages'] = []

    # Right: the conversation
    with a2:
        st.markdown('**AI Assistant**')
        st.caption('Ask about the collected regulatory documents. Answers come only from those documents, '
                   'with links to the sources. Each question is answered on its own.')
        messages = st.session_state.setdefault('messages', [])
        chat = st.container(height=520)
        with chat:
            for m in messages:
                with st.chat_message(m['role']):
                    st.markdown(m['content'])

        question = st.chat_input('Ask a question about regulatory updates') \
            or st.session_state.pop('pending_question', None)
        if question:
            messages.append({'role': 'user', 'content': question})
            with chat:
                with st.chat_message('user'):
                    st.markdown(question)
                with st.chat_message('assistant'):
                    with st.spinner('Searching the regulatory documents...'):
                        # One id per question: it is on the MLflow trace and on every log line of this question
                        request_id = uuid.uuid4().hex
                        set_log_context(request_id=request_id, trace_id=None)
                        try:
                            result = get_agent().answer(question, session_id=SESSION_ID,
                                                        user_hash=USER_HASH, request_id=request_id)
                            reply = result['answer']
                            set_log_context(trace_id=result.get('trace_id'))
                            # Status and tool names only: the question and answer text stay out of the log
                            logger.info('Question handled: status %s, tools %s, guardrail reasons %s',
                                        result['status'], [t.split(' ')[0] for t in result.get('tools') or []],
                                        len(result.get('reasons') or []))
                        except Exception as e:                       # show a clear message instead of a crash
                            logger.exception('AI Assistant error')   # level ERROR, with the full stack trace
                            reply = ('Sorry, the assistant is not available right now. '
                                     f'Reference: {request_id} ({type(e).__name__})')
                    st.markdown(reply)
            messages.append({'role': 'assistant', 'content': reply})

        st.caption('AI generated from the monitored regulatory documents. Check the linked sources. Not legal advice.')
