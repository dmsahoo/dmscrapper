# Regulator module: PARLIAMENT (Parliament of Singapore)
# Version: v0.1
# Based on the client Parliament Bills Scanner specification, adapted to one document per call.

## Source
Publications from the Parliament of Singapore (www.parliament.gov.sg), the Hansard (sprs.parl.gov.sg) and
the Government Gazette (www.egazette.gov.sg): Bills at each reading, Bills passed, Acts assented and
gazetted, Ministerial Statements, Parliamentary Questions, Budget and Committee of Supply debates, and
commencement notifications.

## Treatment tiers
1. Tier 1, full assessment (RELEVANT): financial sector Bills (banking, capital markets, insurance, payment
   services, financial advisers, securities) and cross cutting Bills with material financial sector impact
   (data protection, AML, CFT and sanctions, corporate law, cybersecurity, employment).
   Ministerial Statements on financial sector policy and Parliamentary Questions on banking or regulation
   are also Tier 1 when materially relevant to the bank.
2. Tier 2, awareness entry: Bills not related to the financial sector. Set relevance NOT_RELEVANT,
   importance Low, relevance_reason: Awareness entry, included for CPDAP CPL calendar completeness.
   Keep the other fields short.
3. Tier 3: Tax and CPF Bills, relevance EXCLUDED.

## Parliament specific rules
1. Put the Bill number or Act number in law_or_regulation where given.
2. Report the exact stage reached. A Bill at first reading is not a passed Act. In summary_key_items give
   the lifecycle dates stated in the document: first reading, second reading, passing, presidential assent,
   gazette and commencement, and any related subsidiary legislation expected.
3. date_introduced: the first reading date for a Bill, or N.A. for a statement.
4. effective_date: the commencement date if stated, otherwise Not Stated, or N.A. for a statement.
   If the Act is pending assent or pending commencement, say so in summary_key_items.
5. intention_background: include the Bill sponsor and the policy rationale where stated.

## Field guidance
1. compliance_risk_category: by topic, one of AML, CFT, Sanctions, Data Protection, Conduct,
   Operational Risk, Cybersecurity, Other.
2. proposed_action_timeline: Bills at a reading stage, a monitoring plan; passed Acts, gap assessment and
   implementation timeline; Ministerial Statements, an awareness note.
