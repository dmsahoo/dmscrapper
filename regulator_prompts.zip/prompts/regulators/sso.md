# Regulator module: SSO (Singapore Statutes Online)
# Version: v0.1
# Based on the client SSO Statutes Scanner specification, adapted to one document per call.

## Source
Singapore Statutes Online (sso.agc.gov.sg), the authoritative source for legislative status: new Acts,
Amendment Acts, Subsidiary Legislation (regulations, rules, orders, notifications) and commencement
notifications, from the Acts Supplement, SL Supplement and Bills Supplement.

## Treatment tiers
1. Tier 1, full assessment (RELEVANT): financial sector Acts (Banking, Securities and Futures, Payment
   Services, Financial Advisers, Insurance, Financial Services and Markets), cross cutting Acts with
   material financial sector impact (Companies Act, PDPA, CDSA, TSOFA, Cybersecurity Act), subsidiary
   legislation under MAS administered Acts, and commencement notifications for these.
2. Tier 2, awareness entry: Acts and subsidiary legislation not related to the financial sector. Set
   relevance NOT_RELEVANT, importance Low, relevance_reason: Awareness entry, included for CPDAP CPL
   calendar completeness. Keep the other fields short.
3. Tier 3: Tax and CPF Acts and subsidiary legislation, relevance EXCLUDED.

## SSO specific rules
1. Put the Act number or the S number (subsidiary legislation number) in law_or_regulation where given.
2. Distinguish three dates where the document gives them: gazette publication date, presidential assent
   date, and effective or commencement date. Mention all of them in summary_key_items.
3. date_introduced: the assent date for an Act, or the gazette date for subsidiary legislation.
   Use N.A. for items that are still pending.
4. effective_date: the commencement date if stated, otherwise Not Stated. For phased Acts (for example the
   CALA Act 2025), use the commencement date of the tranche in this document, and in summary_key_items give
   the tranche, its provisions, and later tranche dates if stated or that they are pending.
5. Where the document refers to them, mention the originating Bill number and the administering regulator
   (ACRA for corporate, MAS for financial sector, PDPC for data protection).

## Field guidance
1. compliance_risk_category: by topic, one of AML, CFT, Sanctions, Data Protection, Conduct,
   Operational Risk, Cybersecurity, Other.
2. proposed_action_timeline: gap assessment and implementation by the commencement date where stated.
