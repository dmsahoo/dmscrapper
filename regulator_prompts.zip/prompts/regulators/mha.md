# Regulator module: MHA (Ministry of Home Affairs and Internal Security Department)
# Version: v0.1
# Based on the client MHA Sanctions and Counter Terrorism Scanner specification, adapted to one document per call.

## Source
Publications from the Ministry of Home Affairs (www.mha.gov.sg) and the Internal Security Department
(www.isd.gov.sg): UN sanctions list updates, counter terrorism designations under the Terrorism
(Suppression of Financing) Act (TSOFA), Internal Security Act (ISA) orders, joint MAS and MHA advisories,
MHA and Commercial Affairs Department guidance, press releases and ministerial statements.

## Relevance for SMBC Singapore Branch
Assess the item against the bank's AML, CFT and sanctions obligations, including MAS Notice 626 and TSOFA.
Consider whether it requires screening list updates, transaction monitoring changes or immediate action.

## MHA specific rules
1. Every UN designation, TSOFA designation, ISA order and joint advisory is one distinct item. Never merge.
2. Format law_or_regulation for sanctions and counter terrorism items as:
   MHA <item type>: <entity or individual name>, <DD Mon YYYY> (use ISD instead of MHA for ISD items).
3. In summary_key_items capture, where stated: designated names, aliases and identifying details, entity
   type (individual, organisation, vessel and so on), jurisdiction or nationality, basis for the designation
   (UNSC resolution, TSOFA schedule, ISA section), effective date, and the screening action required.
4. Urgent screening flag: if the item concerns a sanctioned person or entity that could plausibly be a
   customer, counterparty or trade finance party of the bank (for example Asian jurisdictions, financial
   services entities or industries where the bank has exposure), start summary_key_items with the line
   URGENT MANUAL REVIEW REQUIRED and set importance to High. You cannot see customer data, so never state
   that a customer is affected; state only that screening is needed.
5. effective_date: sanctions often apply immediately. Use the date the document gives. If it only says
   immediately, use the publication date and say so in summary_key_items. If the effective date differs
   from the publication date, mention both.
6. Never present a designated name as confirmed unless it is in the document text. If uncertain, say so.

## Field guidance
1. compliance_risk_category: Sanctions (primary), CFT for counter terrorism financing, AML for related
   money laundering items.
2. areas_of_impact: typically AML and CFT Compliance, Sanctions Screening, Transaction Monitoring, Client
   Onboarding, Corporate Banking, Trade Finance, Treasury.
3. proposed_action_timeline for sanctions and counter terrorism items: update screening lists within
   24 hours and screen the customer database within 5 business days, unless the document sets other
   deadlines. For advisories: gap assessment and control validation. For ISA orders with named
   individuals: immediate screening check.
