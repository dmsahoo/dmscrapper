# Regulator module: MOM (Ministry of Manpower)
# Version: v0.1
# Based on the client MOM Employment Scanner specification, adapted to one document per call.

## Source
Publications from the Ministry of Manpower (www.mom.gov.sg): Employment Act and related legislation
(Retirement and Re employment Act, Employment of Foreign Manpower Act, Workplace Fairness Act, Platform
Workers Act), Work Pass policy (EP, S Pass, Work Permit, ONE Pass, PEP, COMPASS, Fair Consideration
Framework, levies), Workplace Safety and Health, policy announcements and consultations, and operational
eServices (myMOM Portal).

## Relevance for SMBC Singapore Branch
Assess the item against the bank's obligations as an employer in Singapore, including its foreign workforce.

## Treatment tiers
1. Tier 1, full assessment (RELEVANT): Work Pass threshold changes affecting the bank's foreign workforce,
   Employment Act amendments with mandatory compliance, retirement and re employment age changes, Workplace
   Fairness Act commencement, Local Qualifying Salary changes, and material WSH obligations.
2. Tier 2, awareness entry: Committee of Supply speeches with content near the financial sector,
   tripartite advisories on emerging issues, eService announcements without new obligations, WSH campaigns.
   Set relevance NOT_RELEVANT, importance Low, relevance_reason: Awareness entry, included for CPDAP CPL
   calendar completeness.
3. Tier 3: CPF matters, relevance EXCLUDED.

## Work Pass threshold discipline (highest accuracy risk)
1. Always say which pass a threshold applies to: EP, S Pass or Work Permit. Never mix them.
2. Always state the sector. The Financial Services threshold is higher than the general one. Give both
   values when the document gives both.
3. Distinguish the announcement date, the effective date for new applications and the effective date for
   renewals. These are often 6 to 18 months apart.
4. If you are not sure which pass a threshold applies to, do not guess: write Requires verification in
   summary_key_items and set importance to Pending Review.

## Field guidance
1. date_introduced: the announcement or publication date.
2. effective_date: the implementation date for new applications if stated, otherwise Not Stated. Give the
   renewal date in summary_key_items. For phased changes, describe the phases in summary_key_items.
3. compliance_risk_category: Other (HR and employment, primary), Conduct for workplace conduct matters.
4. areas_of_impact: typically HR, Talent Acquisition, Compensation and Benefits, Immigration and
   Mobility, Legal, Compliance.
