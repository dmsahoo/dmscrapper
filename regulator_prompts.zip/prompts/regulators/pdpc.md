# Regulator module: PDPC (Personal Data Protection Commission)
# Version: v0.1
# Based on the client PDPC Regulatory Scanner specification, adapted to one document per call.

## Source
Publications from the Personal Data Protection Commission (www.pdpc.gov.sg), which administers the
Personal Data Protection Act (PDPA) and the Do Not Call rules: Advisory Guidelines, Public Consultations,
Responses to Feedback, Commission's Decisions, Voluntary Undertakings, Advisories, Sector Specific
Guidelines and Media Releases.

## Relevance for SMBC Singapore Branch
SMBC Singapore Branch is a foreign bank branch with a wholesale bank licence. It processes personal data of
customers, employees and counterparties in Singapore, so most PDPA guidance applies to it as an organisation.

## PDPC specific rules
1. Advisory Guidelines (Key Concepts in the PDPA, sector guidelines, AI and personal data, cross border data
   flows): state in summary_key_items what is new or revised, if the document says so.
2. Public Consultations: date_introduced is the consultation date. effective_date is N.A.
   proposed_action_timeline must mention the feedback deadline if the document states one.
3. Responses to Feedback: describe what PDPC decided compared with the consultation, if stated.
4. Commission's Decisions and Voluntary Undertakings: each document is one enforcement item. Never merge
   cases. Format law_or_regulation as: PDPC Decision: <organisation name>, <DD Mon YYYY>
   (or PDPC Voluntary Undertaking: <organisation name>, <DD Mon YYYY>).
   In summary_key_items capture, where stated: organisation name, financial penalty in SGD (or that no
   financial penalty was imposed, and any directions), the obligation breached, the root cause
   (for example no multi factor authentication, unpatched systems, no data protection officer),
   number of individuals affected, and key lessons for SMBC Singapore Branch.
   proposed_action_timeline: a lessons learned action, staff briefing or control check.
5. Media releases, advisories, Trusted Data Sharing Framework, DPTM certification, NRIC and authentication
   advisories, MOUs: usually lower importance unless they set new expectations for organisations.

## Field guidance
1. compliance_risk_category: Data Protection (primary). Use Cybersecurity for data security breach cases,
   and Conduct for consent or marketing (Do Not Call) cases.
2. areas_of_impact: typically Data Protection Officer, Legal, Compliance, IT and Information Security, HR,
   Corporate Banking. Say how each is affected.
3. Never state a penalty amount, name or number of individuals that is not in the document.
