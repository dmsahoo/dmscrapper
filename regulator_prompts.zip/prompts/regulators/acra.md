# Regulator module: ACRA (Accounting and Corporate Regulatory Authority)
# Version: v0.1
# Based on the client ACRA Regulatory Scanner specification, adapted to one document per call.

## Source
Publications from the Accounting and Corporate Regulatory Authority (www.acra.gov.sg): Practice Directions,
Registrar's Interpretations, Audit Practice Bulletins, Notices and Circulars (filing requirements, XBRL,
BizFile+ changes, fees), Legislation Updates (Companies Act, Corporate Service Providers Act, Accountants
Act, CALA Act 2025, subsidiary legislation), Policy and Consultations, and News Announcements.

## Foreign branch scope rule
SMBC Singapore Branch is a foreign bank branch registered with ACRA, NOT a Singapore incorporated company.
1. Items that apply only to Singapore incorporated companies: relevance NOT_RELEVANT, unless the item
   sets a supervisory pattern that applies to all registered entities.
2. Items that apply to all registered entities, including foreign branches: RELEVANT.
3. Items for public accountants or audit firms: RELEVANT only if the bank's statutory auditor is affected.
4. If it is unclear whether foreign branches are in scope: RELEVANT, and add to relevance_reason:
   Foreign branch applicability, SME confirmation required.

## ACRA specific rules
1. Consultations: date_introduced is the consultation date, effective_date is N.A., and
   proposed_action_timeline mentions the feedback deadline if stated.
2. CALA Act 2025 tranches: in summary_key_items give the tranche (Tranche 1, Tranche 2 and so on), the
   provisions in that tranche, its commencement date and the next known tranche date if stated.
   effective_date is the commencement date of this tranche, or Not Stated.
3. Enforcement actions against public accountants, audit firms, corporate service providers or filing
   parties: each document is one item, never merged. Format law_or_regulation as:
   ACRA Enforcement Action: <entity or individual>, <DD Mon YYYY>. In summary_key_items capture the name,
   fine in SGD or sanction, breach type, root cause and key lessons for the bank (filing accuracy,
   auditor oversight).
4. Skills Framework, sector partnerships and digitalisation announcements: usually Low importance.

## Field guidance
1. compliance_risk_category: Other (corporate compliance, primary), Conduct for audit matters,
   Operational Risk for filing and reporting impacts.
2. areas_of_impact: typically Company Secretary, Legal, Finance and Statutory Reporting, Compliance,
   Audit Coordination, HR.
3. proposed_action_timeline: consultations, a monitoring plan; legislation, gap assessment and
   implementation; enforcement, a lessons learned action.
