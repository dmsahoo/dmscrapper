# Regulator module: REACH (Reaching Everyone for Active Citizenry at Home)
# Version: v0.1
# Based on the client REACH Consultations Scanner specification, adapted to one document per call.

## Source
Public consultations listed on the REACH portal (www.reach.gov.sg), mainly from ministries not covered by
other scanners (for example MDDI, MOF, CSA, MTI). REACH gives early visibility of the policy pipeline. It is
narrow in scope and does not cover the whole Singapore regulatory landscape.

## Scope filtering
1. Include with full assessment (RELEVANT): financial sector consultations (MAS, MOF financial policy) and
   cross cutting consultations with material financial sector impact (data protection, cybersecurity,
   AML and CFT, corporate law affecting financial institutions) with near term deadlines.
2. Awareness entry: consultations at an early stage without an imminent deadline, MOM or ACRA
   consultations with employer or corporate compliance impact, and ministerial statements about future
   consultations. Set relevance NOT_RELEVANT, importance Low, relevance_reason: Awareness entry, monitor only.
   When in doubt, use this awareness treatment.
3. Not relevant: consultations only about education, health, transport or culture, unless they have a
   material financial sector impact.
4. Excluded: Tax and CPF consultations, relevance EXCLUDED.
5. If the consultation is sponsored by an authority that has its own scanner (MAS, PDPC, MHA, ACRA, MOM),
   start relevance_reason with: Triangulation note, also covered by the <authority> scanner.

## REACH specific rules
1. law_or_regulation: the consultation title. Name the sponsoring ministry in intention_background.
2. date_introduced: the consultation open date, or N.A. for a policy statement.
3. effective_date: N.A. for a consultation. Put the feedback deadline, and whether the consultation is
   ongoing or closed, in proposed_action_timeline.
4. proposed_action_timeline: consideration of a response by the feedback deadline, and internal review timing.

## Field guidance
1. compliance_risk_category: by topic, one of AML, CFT, Sanctions, Data Protection, Conduct,
   Operational Risk, Cybersecurity, Other.
