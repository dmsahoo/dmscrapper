# Databricks notebook source
# MAGIC %md
# MAGIC # Resolve regulators (first task of the scrape job)
# MAGIC
# MAGIC Turns the job parameter `regulators` into the list of regulators to scrape in this run,
# MAGIC and passes it to the next tasks as the task value `regulator_ids`.
# MAGIC
# MAGIC 1. `ALL` (default): every regulator with `enabled: true` in `config/common_config.yaml`.
# MAGIC 2. `MAS` or `PDPC`: only that regulator.
# MAGIC 3. `MAS,PDPC`: several regulators, comma separated.
# MAGIC
# MAGIC The For each task `scrape_regulators` then runs `01_orchestrator` once per regulator in the list.

# COMMAND ----------

# This notebook sits in the repository root, next to the scrapers and config folders.
# Databricks adds the notebook folder to the Python path and makes it the working directory
# (Runtime 14.0 and above), so the imports and the relative config paths work without os or sys.
from scrapers.settings import ConfigError, load_common_config, resolve_regulator_ids
from scrapers.tracking import get_logger

logger = get_logger()

# COMMAND ----------

dbutils.widgets.text('regulators', 'ALL')
dbutils.widgets.text('common_config_path', 'config/common_config.yaml')

PARAM_REGULATORS = dbutils.widgets.get('regulators').strip()
COMMON_CONFIG_PATH = dbutils.widgets.get('common_config_path').strip()      # relative to this folder

# COMMAND ----------

try:
    common = load_common_config(COMMON_CONFIG_PATH)
    REGULATOR_IDS = resolve_regulator_ids(common, PARAM_REGULATORS)
except (ConfigError, ValueError) as error:
    logger.error('Cannot resolve regulators from %r: %s', PARAM_REGULATORS, error)
    raise

logger.info('Parameter regulators %r resolved to %s', PARAM_REGULATORS or 'ALL', REGULATOR_IDS)

# COMMAND ----------

try:
    dbutils.jobs.taskValues.set(key='regulator_ids', value=REGULATOR_IDS)
except Exception as error:
    logger.error('Could not set the task value regulator_ids: %s', error)
    raise

dbutils.notebook.exit(','.join(REGULATOR_IDS))
