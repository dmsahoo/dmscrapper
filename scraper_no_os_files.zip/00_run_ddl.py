# Databricks notebook source
# MAGIC %md
# MAGIC # 00 Run DDL (External ADB workspace)
# MAGIC
# MAGIC Creates or updates the scraper schema, tables and monitoring views for one environment.
# MAGIC The SQL files in the `ddl` folder use `${catalog}.${schema}` instead of real names.
# MAGIC This notebook fills them from the config file and runs the files in name order (01, 02, 03).
# MAGIC
# MAGIC Parameters: `common_config_path` (default config/common_config.yaml, the same parameter the scraper job uses)
# MAGIC and `files` (ALL, or a comma separated list such as 03_monitoring_views).

# COMMAND ----------

# Read the catalog and schema from the config file, so nothing is hardcoded here
# This notebook sits in the repository root, so config/ and ddl/ are relative to the working directory
# (Databricks Runtime 14.0 and above). No os or sys is needed.
import re
from pathlib import Path

import yaml

dbutils.widgets.text('common_config_path', 'config/common_config.yaml')
dbutils.widgets.text('files', 'ALL')
CONFIG_PATH = dbutils.widgets.get('common_config_path').strip()
FILES = dbutils.widgets.get('files').strip()
with open(CONFIG_PATH, encoding='utf8') as f:
    CFG = yaml.safe_load(f)                                  # plain settings only, never runs code
print('Settings from', CONFIG_PATH)

# The placeholders used in the SQL files, and their values
VALUES = {'${catalog}': CFG['catalog'], '${schema}': CFG['schema']}

# COMMAND ----------

# Fill the placeholders in one SQL file, remove comments, and split it into single statements
def statements_of(path):
    text = path.read_text(encoding='utf8')
    for placeholder, value in VALUES.items():
        text = text.replace(placeholder, value)
    left = re.findall(r'\$\{[a-z_]+\}', text)
    if left:
        raise ValueError(f'{path.name}: no value in the config for {sorted(set(left))}')
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)                  # remove /* block comments */
    text = '\n'.join(line for line in text.splitlines() if not line.strip().startswith('--'))   # remove -- comments
    return [s.strip() for s in re.split(r';\s*(?:\n|$)', text) if s.strip()]


# Pick the files to run: all of them, or only the ones named in the files widget
paths = sorted(Path('ddl').glob('*.sql'), key=lambda p: p.name)
if FILES.upper() != 'ALL':
    wanted = {f.strip().replace('.sql', '') for f in FILES.split(',')}
    paths = [p for p in paths if p.stem in wanted]

# COMMAND ----------

# Run every statement, file by file, and stop at the first error so nothing runs half done
for path in paths:
    statements = statements_of(path)
    print(f'{path.name}: {len(statements)} statements')
    for statement in statements:
        spark.sql(statement)
print('All DDL files ran successfully')
