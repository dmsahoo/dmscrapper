"""
Safe readers for notebook widgets.

Every widget value is checked before it is used, so a value typed in a widget (or passed by a job)
can never change a SQL statement or point to another file. Values that reach SQL are always passed
as parameters (:name), never pasted into the SQL text.
"""
import re

ENVIRONMENTS = ['dev', 'uat', 'prod']                        # the only allowed values of the env widget
REGULATOR_PATTERN = re.compile(r'^[A-Z][A-Z0-9_]{1,19}$')    # for example MAS or PDPC
DOCUMENT_ID_PATTERN = re.compile(r'^[0-9a-f]{64}$')          # document ids are SHA 256 fingerprints


# Environment: a dropdown, so only dev, uat or prod can be chosen
def env_widget(dbutils, default='dev'):
    dbutils.widgets.dropdown('env', default, ENVIRONMENTS)
    env = dbutils.widgets.get('env').strip().lower()
    if env not in ENVIRONMENTS:                               # a job can still pass any text, so check again
        raise ValueError(f'env must be one of {ENVIRONMENTS}')
    return env


# A whole number within limits, for example max_files. Empty means the default
def int_widget(dbutils, name, default, low, high):
    dbutils.widgets.text(name, str(default))
    text = dbutils.widgets.get(name).strip() or str(default)
    if not text.isdigit() or not low <= int(text) <= high:
        raise ValueError(f'{name} must be a whole number from {low} to {high}')
    return int(text)


# Regulator: ALL, or one regulator id such as MAS
def regulator_widget(dbutils, default='ALL'):
    dbutils.widgets.text('regulator_id', default)
    value = dbutils.widgets.get('regulator_id').strip().upper() or 'ALL'
    if value != 'ALL' and not REGULATOR_PATTERN.match(value):
        raise ValueError('regulator_id must be ALL or a regulator id such as MAS')
    return value


# Document id: empty, or one SHA 256 document id (64 hexadecimal characters)
def document_id_widget(dbutils):
    dbutils.widgets.text('document_id', '')
    value = dbutils.widgets.get('document_id').strip().lower()
    if value and not DOCUMENT_ID_PATTERN.match(value):
        raise ValueError('document_id must be empty or a 64 character document id')
    return value


# DDL files to run: ALL, or file names from the ddl folder. Any other name stops the run
def files_widget(dbutils, available):
    dbutils.widgets.text('files', 'ALL')
    text = dbutils.widgets.get('files').strip()
    if text.upper() == 'ALL':
        return list(available)
    wanted = {f.strip().replace('.sql', '') for f in text.split(',') if f.strip()}
    unknown = wanted - set(available)
    if unknown:
        raise ValueError(f'Unknown DDL files {sorted(unknown)}. Known: {sorted(available)}')
    return [f for f in available if f in wanted]
