"""
Shared settings loader for the internal workspace.

Every notebook, the Q and A Agent and the app read their names (catalog, schema, tables, model,
endpoints) from one file per environment: config/dev.yaml, config/uat.yaml or config/prod.yaml.
Nothing is hardcoded in the code, so the same code runs in every environment.

How the environment is chosen:
    notebooks and jobs   the env widget or job parameter (default dev)
    the Databricks App   the RCM_ENV environment variable in app.yaml (default dev)

Where each object lives (P02 naming, one schema per layer, catalog ucai<env>):
    bronze   sng_rcm_bronze   raw copies of the documents and their copy log
    silver   sng_rcm_silver   extracted text of every document version
    gold     sng_rcm_gold     chunks, CPDAP CPL records, differences and the app views
    ai       sng_rcm_ai       embeddings, search functions, vector index, app log and traces
"""
import os

import yaml                                   # PyYAML, already available on Databricks runtimes and serverless

# Every table, view, function and index of the internal workspace, and the layer (schema) it belongs to.
# Code asks for an object by name, for example table(cfg, 'document_content'), and gets its full name.
OBJECTS = {
    'document_copy_log': 'bronze',
    'document_content': 'silver',
    'document_chunks': 'gold',
    'document_analysis': 'gold',
    'document_diff': 'gold',
    'v_document_analysis_latest': 'gold',
    'v_document_analysis_history': 'gold',
    'v_document_content_parsed': 'gold',
    'chunk_embeddings': 'ai',
    'fn_search_chunks': 'ai',
    'fn_get_changes': 'ai',
    'idx_document_chunks': 'ai',
    'app_log': 'ai',
}


# Find the repository root: the first folder, going up from here, that has both config and common in it
def repo_root():
    folder = os.path.dirname(os.path.abspath(__file__))
    while folder != os.path.dirname(folder):
        if os.path.isdir(os.path.join(folder, 'config')) and os.path.isdir(os.path.join(folder, 'common')):
            return folder
        folder = os.path.dirname(folder)
    raise FileNotFoundError('Repository root with config and common folders not found')


# Read config/<env>.yaml. env comes from the caller, then from RCM_ENV, and defaults to dev
def load_config(env=None):
    env = (env or os.getenv('RCM_ENV') or 'dev').strip().lower()
    if env not in ('dev', 'uat', 'prod'):            # never build a file path from an unchecked value
        raise ValueError(f'Unknown environment {env!r}. Use dev, uat or prod')
    path = os.path.join(repo_root(), 'config', f'{env}.yaml')
    with open(path) as f:
        cfg = yaml.safe_load(f)                   # safe_load: reads plain settings only, never runs code
    cfg['_path'] = path                                   # kept so notebooks can print which file they used
    return cfg


# catalog.schema of one layer (bronze, silver, gold or ai), for example ucaidev.sng_rcm_gold
def schema(cfg, layer):
    return f"{cfg['catalog']}.{cfg['schemas'][layer]}"


# Full name of a table, view, function or index, for example ucaidev.sng_rcm_gold.document_chunks
def table(cfg, name):
    if name not in OBJECTS:
        raise KeyError(f'Unknown object {name!r}. Known objects: {sorted(OBJECTS)}')
    return f'{schema(cfg, OBJECTS[name])}.{name}'


# Full name of a table in the external (scraper) schema, for example <external_catalog>.<external_schema>.pdf_catalog
def external_table(cfg, name):
    return f"{cfg['external_catalog']}.{cfg['external_schema']}.{name}"


# Path of the Bronze volume where copied documents are stored
def volume_path(cfg):
    return f"/Volumes/{cfg['catalog']}/{cfg['schemas']['bronze']}/{cfg['volume']}"


# Placeholders used in the SQL files in the ddl folder, and their values from the config
def sql_placeholders(cfg):
    return {
        '${catalog}': cfg['catalog'],
        '${bronze_schema}': cfg['schemas']['bronze'],
        '${silver_schema}': cfg['schemas']['silver'],
        '${gold_schema}': cfg['schemas']['gold'],
        '${ai_schema}': cfg['schemas']['ai'],
        '${volume}': cfg['volume'],
        '${external_catalog}': cfg['external_catalog'],
        '${external_schema}': cfg['external_schema'],
        '${embedding_model}': cfg['embedding_model'],
        '${app_service_principal}': cfg['app_service_principal'],
    }
