# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 04_refresh_idx_doc_chunks
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Keeps the Vector Search index of the regulatory text up to date. The first time, it creates the index `idx_document_chunks` on the Gold chunk table `document_chunks`, with embeddings made by Databricks from `chunk_text` (no embedding table of our own). Every run after that, it syncs the index with the table and checks that the index holds every chunk. The Q and A Agent searches this index. Replaces `04_embed_chunks`. |
# MAGIC | **Job and task** | Daily ingest job, after the parse task |
# MAGIC | **Parameters** | `env` (dropdown: dev, uat or prod). Checked before use. |
# MAGIC | **Inputs** | `document_chunks` (Gold), the `vector_search` block and `embedding_model` of `config/<env>.yaml` |
# MAGIC | **Outputs** | The Vector Search index `idx_document_chunks`, synced and checked |
# MAGIC | **Compute** | Serverless |
# MAGIC | **Dependencies** | The Vector Search endpoint from the config must exist and be Ready. CREATE TABLE on the internal schema (the index is a Unity Catalog object), MODIFY on `document_chunks` (to turn on Change Data Feed), CAN USE on the endpoint, access to the embedding model |
# MAGIC
# MAGIC Names follow the P02 guideline: endpoint `vs-<branch>-<use_case>-<env>` (or `vs-shared-<env>`), index `idx_<subject>`.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Install the libraries
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Install the Databricks SDK at the same fixed version as `requirements.txt` (no new library), then restart Python. |
# MAGIC | **Input** | None |
# MAGIC | **Output** | Library `databricks-sdk` 0.164.0 |

# COMMAND ----------

# Fixed version, the same as requirements.txt, so the notebook and the app use the same Vector Search client
%pip install --quiet databricks-sdk==0.164.0
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Load the settings
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Load the config for the chosen environment, and read the endpoint, the index name, the embedding model and the time limit. |
# MAGIC | **Input** | Widget `env`, file `config/<env>.yaml` |
# MAGIC | **Output** | `ENDPOINT`, `INDEX_NAME`, `SOURCE_TABLE`, `EMBEDDING_MODEL`, `TIMEOUT_MINUTES` |

# COMMAND ----------

import os
import sys
import time

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.vectorsearch import (DeltaSyncVectorIndexSpecRequest, EmbeddingSourceColumn,
                                                 PipelineType, VectorIndexType)

from common.config import load_config, table
from common.widgets import env_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
print('Settings from', CFG['_path'])

# Names, all from the config file
VS = CFG['vector_search']
ENDPOINT = VS['endpoint']                                # for example vs-sng-rcm-devai
INDEX_NAME = table(CFG, VS['index'])                     # for example ucaidev.sng_rcm_ai.idx_document_chunks
SOURCE_TABLE = table(CFG, 'document_chunks')               # Gold: chunks of the current version
EMBEDDING_MODEL = CFG['embedding_model']                 # Databricks makes the embeddings with this model
TIMEOUT_MINUTES = VS['sync_timeout_minutes']             # how long to wait for the index before failing

# Columns kept in the index: the agent needs them to answer and to build the citation link
COLUMNS_TO_SYNC = ['chunk_id', 'document_id', 'version', 'regulator_id', 'chunk_index', 'section_title',
                   'page_number', 'chunk_text', 'file_name']

w = WorkspaceClient()
print(f'Endpoint {ENDPOINT} | index {INDEX_NAME} | source {SOURCE_TABLE}')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Check the endpoint and the source table
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Stop early with a clear message if the endpoint does not exist or is not ready. Turn on Change Data Feed on `document_chunks`, which a Delta Sync index needs to see what changed. Safe to run again. |
# MAGIC | **Input** | `ENDPOINT`, `SOURCE_TABLE` |
# MAGIC | **Output** | Change Data Feed on, and `TABLE_ROWS` (the number of chunks the index must hold) |

# COMMAND ----------

# The endpoint must exist and be ready (it is created once, by hand or by the platform team)
state = w.vector_search_endpoints.get_endpoint(ENDPOINT).endpoint_status.state.value
if state != 'ONLINE':
    raise RuntimeError(f'Vector Search endpoint {ENDPOINT} is {state}, not ONLINE. Wait until it shows Ready.')

# A Delta Sync index reads the changes of the table, so Change Data Feed must be on
spark.sql(f'ALTER TABLE {SOURCE_TABLE} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)')

TABLE_ROWS = spark.table(SOURCE_TABLE).count()
print(f'Endpoint {ENDPOINT} is ONLINE. {SOURCE_TABLE} has {TABLE_ROWS} chunks, Change Data Feed on.')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Create the index if it does not exist, otherwise sync it
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | The first run creates a Delta Sync index with managed embeddings: Databricks turns `chunk_text` into embeddings with the model from the config. Triggered means it syncs only when asked, so it costs nothing between runs. Later runs ask for a sync, so new and changed chunks are added and old ones removed. |
# MAGIC | **Input** | `INDEX_NAME`, `ENDPOINT`, `SOURCE_TABLE`, `EMBEDDING_MODEL`, `COLUMNS_TO_SYNC` |
# MAGIC | **Output** | The index exists and a sync has started |

# COMMAND ----------

# Does the index exist already ?
try:
    w.vector_search_indexes.get_index(INDEX_NAME)
    exists = True
except Exception:
    exists = False

if not exists:
    # First run: create the index. Its first sync starts by itself
    w.vector_search_indexes.create_index(
        name=INDEX_NAME,
        endpoint_name=ENDPOINT,
        primary_key='chunk_id',
        index_type=VectorIndexType.DELTA_SYNC,
        delta_sync_index_spec=DeltaSyncVectorIndexSpecRequest(
            source_table=SOURCE_TABLE,
            pipeline_type=PipelineType.TRIGGERED,                    # sync only when asked: no cost between runs
            embedding_source_columns=[EmbeddingSourceColumn(name='chunk_text',
                                                            embedding_model_endpoint_name=EMBEDDING_MODEL)],
            columns_to_sync=COLUMNS_TO_SYNC))
    print(f'Created {INDEX_NAME}. Its first sync has started.')
else:
    # Later runs: ask for a sync. If a sync is already running, that one is used
    try:
        w.vector_search_indexes.sync_index(INDEX_NAME)
        print(f'Sync of {INDEX_NAME} started.')
    except Exception as error:
        print(f'Sync not started ({type(error).__name__}): a sync may already be running, waiting for it.')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5: Wait for the index and check that it holds every chunk
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Wait until the index is ready and holds as many rows as the chunk table. If that does not happen within the time limit, the run fails, so a stale index is visible in the job history instead of silently answering from old text. |
# MAGIC | **Input** | `INDEX_NAME`, `TABLE_ROWS`, `TIMEOUT_MINUTES` |
# MAGIC | **Output** | `INDEXED_ROWS`, the run fails if the index is not complete |

# COMMAND ----------

deadline = time.time() + TIMEOUT_MINUTES * 60
INDEXED_ROWS = None
while time.time() < deadline:
    status = w.vector_search_indexes.get_index(INDEX_NAME).status
    INDEXED_ROWS = status.indexed_row_count
    print(f'ready={status.ready} indexed={INDEXED_ROWS} of {TABLE_ROWS}')
    if status.ready and INDEXED_ROWS == TABLE_ROWS:
        break
    time.sleep(30)                                       # check again every 30 seconds
else:
    raise RuntimeError(f'{INDEX_NAME} holds {INDEXED_ROWS} rows, expected {TABLE_ROWS}, '
                       f'after {TIMEOUT_MINUTES} minutes. Check the index page for the sync error.')

print(f'{INDEX_NAME} is ready and holds all {INDEXED_ROWS} chunks.')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 6: Test one search
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Run one hybrid search (meaning plus keywords), the same kind the Q and A Agent uses, to prove the index answers. The test question is fixed text, never user data. |
# MAGIC | **Input** | `INDEX_NAME`, `vector_search.query_type` from the config |
# MAGIC | **Output** | The three best chunks in the notebook output |

# COMMAND ----------

result = w.vector_search_indexes.query_index(
    index_name=INDEX_NAME,
    columns=['chunk_id', 'file_name', 'page_number', 'section_title'],
    query_text='net stable funding ratio',
    query_type=VS['query_type'],                         # HYBRID: meaning plus keywords
    num_results=3)
columns = [c.name for c in result.manifest.columns]
for row in result.result.data_array or []:
    print(dict(zip(columns, row)))

dbutils.notebook.exit(f'{INDEX_NAME} synced: {INDEXED_ROWS} chunks')