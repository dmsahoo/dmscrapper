# Databricks notebook source
# MAGIC %md
# MAGIC # 02_parse_and_chunk
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Turns the copied documents into searchable text. PDF text is extracted with `ai_parse_document`, HTML text with the Python standard library. The full text is saved to Silver (`document_content`, every version kept), the chunks of the current version to Gold (`document_chunks`), and each document is marked INGESTED or FAILED. |
# MAGIC | **Job and task** | Daily ingest job, after the copy job |
# MAGIC | **Parameters** | `env` (dropdown: dev, uat or prod). `max_documents` (empty means the value in the config). Every value is checked before use. |
# MAGIC | **Inputs** | `document_copy_log` (copied documents with ingest_status PENDING), the files in the internal volume, `config/<env>.yaml` |
# MAGIC | **Outputs** | Rows in `document_content` and `document_chunks`, ingest_status in `document_copy_log` |
# MAGIC | **Compute** | Serverless (environment version 3 or above), or Databricks Runtime 17.3 or above |
# MAGIC | **Dependencies** | READ VOLUME on the internal volume, MODIFY on the three tables, access to `ai_parse_document` |

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Load the settings and define the helpers
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Import the libraries, load the config for the chosen environment, read the table names and chunk sizes, and check `max_documents` (a whole number from 1 to 1000). Define the current time helper and a SQL call that retries briefly. |
# MAGIC | **Input** | Widgets `env`, `max_documents`; file `config/<env>.yaml` |
# MAGIC | **Output** | Table names, chunk sizes, `MAX_DOCUMENTS`, functions `now_sgt` and `run_sql` |

# COMMAND ----------

import json
import os
import sys
import time
from datetime import datetime
from html.parser import HTMLParser
from zoneinfo import ZoneInfo

spark.conf.set('spark.sql.session.timeZone', 'Asia/Singapore')     # all SQL times in Singapore time
SGT = ZoneInfo('Asia/Singapore')

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

from common.config import load_config, table
from common.widgets import env_widget, int_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
print('Settings from', CFG['_path'])

# Names and sizes, all from the config file
PROMOTION_LOG = table(CFG, 'document_copy_log')
CONTENT_TABLE = table(CFG, 'document_content')            # Silver: full text of every version
CHUNK_TABLE = table(CFG, 'document_chunks')                # Gold: chunks of the current version
CHUNK_CHARS = CFG['chunking']['chunk_chars']             # about 700 to 800 tokens per chunk
OVERLAP_CHARS = CFG['chunking']['overlap_chars']         # text repeated from the end of the previous chunk, so sentences are not cut off
MIN_TEXT_CHARS = CFG['chunking']['min_text_chars']       # less text than this is treated as a failed parse

# Parameter, checked before use. Empty uses the value in the config
MAX_DOCUMENTS = int_widget(dbutils, 'max_documents', CFG['chunking']['max_documents'], 1, 1000)   # safe in LIMIT


# Current time in Singapore, without time zone, as stored in the tables
def now_sgt():
    return datetime.now(SGT).replace(tzinfo=None)


# Run a SQL statement with parameters, retrying briefly if another job is writing the same table
def run_sql(sql, args=None, attempts=3):
    for i in range(1, attempts + 1):
        try:
            return spark.sql(sql, args=args or {})
        except Exception:
            if i == attempts:
                raise                                    # give up after the last attempt
            time.sleep(3 * i)                            # wait 3, then 6 seconds

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Build the work list
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Find the documents that the copy job copied and that are not parsed yet, oldest copy first. |
# MAGIC | **Input** | `document_copy_log` |
# MAGIC | **Output** | `todo` (the documents to parse) |

# COMMAND ----------

todo = spark.sql(f'''
    SELECT document_id, version, regulator_id, content_format, file_name, source_url, internal_file_path
    FROM {PROMOTION_LOG}
    WHERE copy_status = 'COPIED' AND ingest_status = 'PENDING'
    ORDER BY copied_at_sgt
    LIMIT {MAX_DOCUMENTS}
''').collect()
print(f'{len(todo)} documents to parse')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Define the text extraction
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Define how text is taken out of a document. PDF: `ai_parse_document` returns headings and paragraphs with their page, and page headers, footers and numbers are skipped. HTML: a small parser keeps headings, paragraphs, list items and table rows, and skips scripts, menus and forms. |
# MAGIC | **Input** | File paths in the internal volume |
# MAGIC | **Output** | Functions `parse_pdfs` and `parse_html`, each returning paragraphs as (kind, text, page) |

# COMMAND ----------

SKIP_ELEMENTS = {'page_header', 'page_footer', 'page_number'}       # repeated on every page, not useful for search
HEADING_ELEMENTS = {'title', 'section_header'}                     # these start a new section


# Parse many PDFs in one call. Returns {path: (paragraphs, page_count, error)}.
# paragraphs is a list of (kind, text, page), where kind is heading or text.
def parse_pdfs(paths):
    if not paths:
        return {}
    spark.read.format('binaryFile').load(paths).createOrReplaceTempView('pdf_files')
    rows = spark.sql('''
        SELECT path, to_json(ai_parse_document(content, map('version', '2.0'))) AS parsed
        FROM pdf_files
    ''').collect()
    result = {}
    for r in rows:
        path = r['path'].replace('dbfs:', '', 1)                   # same path form as in document_copy_log
        try:
            doc = json.loads(r['parsed'])
            errors = doc.get('error_status') or []
            paragraphs = []
            for el in (doc.get('document') or {}).get('elements') or []:
                kind = (el.get('type') or '').lower()
                text = (el.get('content') or '').strip()
                if not text or kind in SKIP_ELEMENTS:
                    continue
                bbox = el.get('bbox') or [{}]
                page = (bbox[0] or {}).get('page_id')
                page = page + 1 if isinstance(page, int) else None    # page_id starts at 0
                paragraphs.append(('heading' if kind in HEADING_ELEMENTS else 'text', text, page))
            page_count = len((doc.get('document') or {}).get('pages') or [])
            error = '; '.join(str(e) for e in errors) if errors and not paragraphs else None
            result[path] = (paragraphs, page_count, error)
        except Exception as e:
            result[path] = ([], 0, f'Could not read parser output: {e}')
    return result


# Collects headings, paragraphs, list items and table rows from an HTML snapshot
class _HtmlText(HTMLParser):
    BLOCKS = {'p', 'div', 'li', 'tr', 'br', 'section', 'article'}  # each of these starts a new paragraph
    HEADINGS = {'h1', 'h2', 'h3', 'h4', 'h5', 'h6'}
    SKIP = {'script', 'style', 'noscript', 'nav', 'footer', 'form'}  # menus and code, not content

    # Start with no text collected
    def __init__(self):
        super().__init__()
        self.paragraphs, self.buffer, self.kind, self.skip = [], [], 'text', 0

    # Save the text collected so far as one paragraph (heading or normal text)
    def _flush(self):
        text = ' '.join(''.join(self.buffer).split())
        if text:
            self.paragraphs.append((self.kind, text, None))
        self.buffer, self.kind = [], 'text'

    # An opening tag: skip scripts and menus, and start a new paragraph for headings and blocks
    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.HEADINGS or tag in self.BLOCKS:
            self._flush()
            if tag in self.HEADINGS:
                self.kind = 'heading'
        elif tag in ('td', 'th'):
            self.buffer.append(' | ')                    # keep table cells apart

    # A closing tag: end the skipped part, or end the current paragraph
    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.HEADINGS or tag in self.BLOCKS:
            self._flush()

    # Text between tags: keep it unless it is inside a skipped part
    def handle_data(self, data):
        if not self.skip:
            self.buffer.append(data)


# Extract the paragraphs of an HTML snapshot with the Python standard library
def parse_html(path):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        parser = _HtmlText()
        parser.feed(f.read())
        parser.close()
    parser._flush()                                      # save the last paragraph
    return parser.paragraphs, 0, None

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Define the chunking
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Define how the paragraphs are joined into one text, and how they are grouped into chunks of about `chunk_chars` characters. A new heading starts a new chunk once the current one is at least half full, and each chunk repeats a short overlap from the previous one, so sentences are not cut off. |
# MAGIC | **Input** | Paragraphs from Step 3, `CHUNK_CHARS`, `OVERLAP_CHARS` |
# MAGIC | **Output** | Functions `to_text` and `make_chunks` (each chunk has its section title and first page) |

# COMMAND ----------

# Join the paragraphs into one text. Headings start with ## so chunking can find sections
def to_text(paragraphs):
    return '\n\n'.join(('## ' + t) if k == 'heading' else t for k, t, _ in paragraphs)


# Group paragraphs into chunks of about CHUNK_CHARS characters
def make_chunks(paragraphs):
    chunks, current, size, section, first_page = [], [], 0, '', None

    # Close the current chunk and start a new one, repeating the overlap from the end of the previous chunk
    def emit():
        nonlocal current, size, first_page
        if current:
            chunks.append({'section_title': section_of_chunk, 'page_number': first_page,
                           'chunk_text': '\n\n'.join(current)})
            tail = chunks[-1]['chunk_text'][-OVERLAP_CHARS:]
            current, size, first_page = ([tail], len(tail), None) if OVERLAP_CHARS else ([], 0, None)

    section_of_chunk = ''
    for kind, text, page in paragraphs:
        if kind == 'heading':
            if size >= CHUNK_CHARS / 2:                  # a new section starts a new chunk once this one is half full
                emit()
            section = text
        while text:                                      # a long paragraph is split over several chunks
            room = CHUNK_CHARS - size
            if room <= 0:
                emit()
                room = CHUNK_CHARS - size
            piece, text = text[:room], text[room:]
            if not current or (len(current) == 1 and first_page is None and size <= OVERLAP_CHARS):
                section_of_chunk = section               # the chunk takes the section where its own text starts
            current.append(('## ' + piece) if kind == 'heading' else piece)
            size += len(piece)
            if first_page is None and page:
                first_page = page                        # the first page that this chunk's text comes from
    if size > OVERLAP_CHARS or len(chunks) == 0:         # save the last chunk unless it is only the overlap
        emit()
    return chunks

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5: Parse every document
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Parse all PDFs in one call, then each HTML file. A document with an error, or with less text than `min_text_chars`, is marked as failed. One failed document does not stop the others. |
# MAGIC | **Input** | `todo` |
# MAGIC | **Output** | `content_rows` (Silver), `chunk_rows` (Gold), lists `done` and `failed` |

# COMMAND ----------

pdf_paths = [r['internal_file_path'] for r in todo if r['content_format'] == 'PDF']
pdf_results = parse_pdfs(pdf_paths)                      # all PDFs in one call, faster than one by one

content_rows, chunk_rows, done, failed = [], [], [], []
for r in todo:
    key = {'document_id': r['document_id'], 'version': r['version']}
    try:
        if r['content_format'] == 'PDF':
            paragraphs, pages, error = pdf_results.get(r['internal_file_path'], ([], 0, 'Not returned by parser'))
        else:
            paragraphs, pages, error = parse_html(r['internal_file_path'])
        text = to_text(paragraphs)
        if error or len(text) < MIN_TEXT_CHARS:
            raise ValueError(error or f'Only {len(text)} characters extracted')
        ts = now_sgt()
        # One Silver row with the full text of this version
        content_rows.append((r['document_id'], r['version'], r['regulator_id'], r['content_format'],
                             r['file_name'], r['source_url'], r['internal_file_path'], text,
                             pages or None, 'PARSED', None, ts))
        # One Gold row per chunk. The chunk_id is document_id, version and chunk number
        for i, c in enumerate(make_chunks(paragraphs)):
            chunk_rows.append((f"{r['document_id']}_v{r['version']}_{i:04d}", r['document_id'], r['version'],
                               r['regulator_id'], i, c['section_title'] or None, c['page_number'],
                               c['chunk_text'], len(c['chunk_text']), r['file_name'], r['source_url'], ts))
        done.append(key)
        print(f"PARSED {r['file_name']}")
    except Exception as e:
        failed.append(dict(key, error=f'{type(e).__name__}: {e}'[:4000]))   # keep the error short
        print(f"FAILED {r['file_name']}: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 6: Save the results and mark the documents
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Save the text to Silver and the chunks to Gold. Safe to run again: the same version is replaced in Silver, and Gold keeps only the current version of each document. Then mark each document INGESTED or FAILED in `document_copy_log`. |
# MAGIC | **Input** | `content_rows`, `chunk_rows`, `done`, `failed` |
# MAGIC | **Output** | Rows in `document_content` and `document_chunks`, ingest_status in `document_copy_log` |

# COMMAND ----------

# Column order of the two tables, so the rows above line up with the table schema
content_cols = ['document_id', 'version', 'regulator_id', 'content_format', 'file_name', 'source_url',
                'internal_file_path', 'content_text', 'page_count', 'parse_status', 'parse_error', 'parsed_at_sgt']
chunk_cols = ['chunk_id', 'document_id', 'version', 'regulator_id', 'chunk_index', 'section_title',
              'page_number', 'chunk_text', 'char_count', 'file_name', 'source_url', 'created_at_sgt']

if done:
    keys = spark.createDataFrame([(d['document_id'], d['version']) for d in done], 'document_id string, version int')
    keys.createOrReplaceTempView('done_keys')
    # Rerun safe: replace this version in Silver; in Gold keep only the current version of each document
    run_sql(f'''MERGE INTO {CONTENT_TABLE} t USING done_keys k
                ON t.document_id = k.document_id AND t.version = k.version
                WHEN MATCHED THEN DELETE''')
    run_sql(f'DELETE FROM {CHUNK_TABLE} WHERE document_id IN (SELECT document_id FROM done_keys)')
    spark.table(CONTENT_TABLE).limit(0)                  # check the table exists before writing
    (spark.createDataFrame(content_rows, spark.table(CONTENT_TABLE).select(*content_cols).schema)
         .write.mode('append').saveAsTable(CONTENT_TABLE))
    if chunk_rows:
        (spark.createDataFrame(chunk_rows, spark.table(CHUNK_TABLE).select(*chunk_cols).schema)
             .write.mode('append').saveAsTable(CHUNK_TABLE))
    # Mark the parsed documents as INGESTED
    run_sql(f'''MERGE INTO {PROMOTION_LOG} t USING done_keys k
                ON t.document_id = k.document_id AND t.version = k.version
                WHEN MATCHED THEN UPDATE SET ingest_status = 'INGESTED', ingest_error_details = NULL,
                                             updated_at_sgt = :ts''', {'ts': now_sgt()})

# Mark each failed document as FAILED, with the reason (all values are parameters)
for f in failed:
    run_sql(f'''
        UPDATE {PROMOTION_LOG} SET ingest_status = 'FAILED', ingest_error_details = :error, updated_at_sgt = :ts
        WHERE document_id = :document_id AND version = :version
    ''', {'error': f['error'], 'ts': now_sgt(), 'document_id': f['document_id'], 'version': f['version']})

print(f'{len(done)} parsed, {len(failed)} failed, {len(chunk_rows)} chunks written')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 7: Finish the run
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Fail the job run if any document failed, so the failure is visible in the job history and alerts. Otherwise end with a short summary. |
# MAGIC | **Input** | `done`, `failed`, `chunk_rows` |
# MAGIC | **Output** | Job run status (failed or succeeded) and the exit message |

# COMMAND ----------

if failed:
    raise RuntimeError(f'{len(failed)} documents failed to parse. See document_copy_log where ingest_status = FAILED.')
dbutils.notebook.exit(f'parsed={len(done)} failed={len(failed)} chunks={len(chunk_rows)}')
