# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 06_setup_tracing
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Creates the MLflow experiments of the two agents with a Unity Catalog trace location, so every trace is stored as OpenTelemetry data in Unity Catalog tables (spans, annotations, logs and metrics), governed by the same grants as the other tables. Prints the experiment IDs: the Databricks App (and later ACA) uses the ID in `MLFLOW_EXPERIMENT_ID`, never the name. Gives the app service principal the rights it needs on the trace tables and the experiment. |
# MAGIC | **Job and task** | Run by hand, once per environment |
# MAGIC | **Parameters** | `env` (dropdown: dev, uat or prod). Checked before use. |
# MAGIC | **Inputs** | `tracing` block of `config/<env>.yaml`, `catalog`, `schema`, `sql_warehouse_id`, `app_service_principal` |
# MAGIC | **Outputs** | Two MLflow experiments, the trace tables `<table_prefix>_otel_*` in the internal schema, grants, the experiment IDs in the output |
# MAGIC | **Compute** | Serverless |
# MAGIC | **Dependencies** | MLflow 3.14 or later. The person who runs it needs CREATE TABLE on the internal schema, CAN USE on the SQL warehouse, rights to create experiments in the experiment folder, and MANAGE on the trace tables to give the grants |
# MAGIC
# MAGIC **Important:** an experiment can be bound to a Unity Catalog trace location only when it is created, and never moved later. That is why the experiment names in the config end with `_uc`: the old experiments without a Unity Catalog location stay as they are.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Install the libraries
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Install MLflow with the Databricks extras, at a fixed version that supports Unity Catalog trace locations (3.14 or later), then restart Python. |
# MAGIC | **Input** | None |
# MAGIC | **Output** | Library `mlflow[databricks]` 3.16.1 |

# COMMAND ----------

# Fixed version, the same MLflow version as requirements.txt and the other notebooks
%pip install --quiet mlflow[databricks]==3.16.1
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Load the settings
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Load the config for the chosen environment, and read the trace location, the experiment names, the SQL warehouse and the app service principal. |
# MAGIC | **Input** | Widget `env`, file `config/<env>.yaml` |
# MAGIC | **Output** | `CATALOG`, `SCHEMA`, `TABLE_PREFIX`, `EXPERIMENTS`, `WAREHOUSE_ID`, `APP_SP` |

# COMMAND ----------

import os
import sys

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

import mlflow
from databricks.sdk import WorkspaceClient
from mlflow.entities.trace_location import UnityCatalog
from mlflow.tracing import set_databricks_monitoring_sql_warehouse_id

from common.config import load_config
from common.widgets import env_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
print('Settings from', CFG['_path'])

# Names, all from the config file
CATALOG = CFG['catalog']                                 # trace tables live in the internal catalog
SCHEMA = CFG['schemas']['ai']                            # in the AI schema (sng_rcm_ai)
TABLE_PREFIX = CFG['tracing']['table_prefix']            # tables are named <prefix>_otel_spans and so on
EXPERIMENTS = CFG['tracing']['experiments']              # for example {'qa_agent': '/Shared/rcm/dev/rcm_qa_agent_uc'}
WAREHOUSE_ID = CFG['sql_warehouse_id']                   # used to read traces stored in Unity Catalog
APP_SP = CFG['app_service_principal']                    # Application ID of the Databricks App service principal

mlflow.set_tracking_uri('databricks')                    # traces go to this Databricks workspace
os.environ['MLFLOW_TRACING_SQL_WAREHOUSE_ID'] = WAREHOUSE_ID

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Create the experiments with a Unity Catalog trace location
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Create each experiment (or reuse it if it already exists with the same location), bound to the Unity Catalog trace location. Both experiments share one location, so all agent traces land in the same four tables. Set the SQL warehouse on each experiment, which the Traces tab and production monitoring need. |
# MAGIC | **Input** | `EXPERIMENTS`, `CATALOG`, `SCHEMA`, `TABLE_PREFIX`, `WAREHOUSE_ID` |
# MAGIC | **Output** | `EXPERIMENT_IDS` (agent name to experiment ID), the trace tables in the internal schema |

# COMMAND ----------

# The experiment folder must exist before an experiment can be created in it
w = WorkspaceClient()
for path in EXPERIMENTS.values():
    w.workspace.mkdirs(os.path.dirname(path))

location = UnityCatalog(catalog_name=CATALOG, schema_name=SCHEMA, table_prefix=TABLE_PREFIX)

EXPERIMENT_IDS = {}
for agent, path in EXPERIMENTS.items():
    # set_experiment creates the experiment if it does not exist, or reuses it if it does.
    # The trace location can only be set at creation: an old experiment without it cannot be moved.
    experiment = mlflow.set_experiment(experiment_name=path, trace_location=location)
    EXPERIMENT_IDS[agent] = experiment.experiment_id
    # The SQL warehouse that reads these traces (the Traces tab and monitoring need it on the experiment)
    set_databricks_monitoring_sql_warehouse_id(sql_warehouse_id=WAREHOUSE_ID,
                                               experiment_id=experiment.experiment_id)
    print(f'{agent}: {path}  ID {experiment.experiment_id}')

print('Spans table:', experiment.trace_location.full_otel_spans_table_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Give the app service principal its rights
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Let the app write and read its traces. The Databricks docs require MODIFY and SELECT on each trace table, granted one by one (ALL PRIVILEGES is not enough), and CAN EDIT on the experiment. Table names come from the config, and the principal is the Application ID from the config. |
# MAGIC | **Input** | `APP_SP`, `TABLE_PREFIX`, `EXPERIMENT_IDS` |
# MAGIC | **Output** | Grants on the four trace tables, CAN EDIT on the Q and A Agent experiment |

# COMMAND ----------

from databricks.sdk.service.ml import ExperimentAccessControlRequest, ExperimentPermissionLevel

# MODIFY and SELECT on each of the four trace tables (explicit grants, as the docs require)
for kind in ['spans', 'annotations', 'logs', 'metrics']:
    trace_table = f'{CATALOG}.{SCHEMA}.{TABLE_PREFIX}_otel_{kind}'
    if not spark.catalog.tableExists(trace_table):
        print(f'Not found yet, skipped: {trace_table}')
        continue
    spark.sql(f'GRANT MODIFY, SELECT ON TABLE {trace_table} TO `{APP_SP}`')
    print(f'Granted MODIFY and SELECT on {trace_table}')

# CAN EDIT on the Q and A Agent experiment, which the app writes to (other permissions are kept)
w.experiments.update_permissions(
    experiment_id=EXPERIMENT_IDS['qa_agent'],
    access_control_list=[ExperimentAccessControlRequest(service_principal_name=APP_SP,
                                                        permission_level=ExperimentPermissionLevel.CAN_EDIT)])
print('Granted CAN EDIT on the Q and A Agent experiment')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5: Check that a trace is stored in Unity Catalog
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Write one small test trace to each experiment and read it back, to prove the whole path works: MLflow, the Unity Catalog tables and the SQL warehouse. The test trace holds no personal data. |
# MAGIC | **Input** | `EXPERIMENT_IDS` |
# MAGIC | **Output** | One test trace per experiment, and the IDs to copy into `app.yaml` and the config |

# COMMAND ----------

import time


# A tiny traced function: the input and output are fixed text, never user data
@mlflow.trace(name='setup_tracing_check')
def tracing_check(text):
    return text.upper()


for agent, experiment_id in EXPERIMENT_IDS.items():
    mlflow.set_experiment(experiment_id=experiment_id)
    tracing_check('tracing works')

time.sleep(30)                                           # traces are written in the background, so wait briefly

for agent, experiment_id in EXPERIMENT_IDS.items():
    found = mlflow.search_traces(experiment_ids=[experiment_id], max_results=5)
    print(f'{agent}: {len(found)} traces found in experiment {experiment_id}')

print('\nCopy these IDs:')
print(f"  app.yaml           MLFLOW_EXPERIMENT_ID = {EXPERIMENT_IDS['qa_agent']}")
print(f"  config/<env>.yaml  tracing.experiment_ids = {EXPERIMENT_IDS}")