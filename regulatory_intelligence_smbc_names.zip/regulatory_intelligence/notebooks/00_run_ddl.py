# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 00_run_ddl
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Creates or updates the schema, volume, tables, views, functions and app grants of the internal workspace for one environment. Safe to run again: tables use CREATE IF NOT EXISTS, views and functions use CREATE OR REPLACE, and the grants file runs last, so grants removed by CREATE OR REPLACE are given back. |
# MAGIC | **Job and task** | Run by hand, once per environment and after every DDL change |
# MAGIC | **Parameters** | `env` (dropdown: dev, uat or prod). `files` (ALL, or a comma separated list of DDL file names such as 05_app_view,10_app_grants). Every value is checked before use. |
# MAGIC | **Inputs** | `config/<env>.yaml`, the SQL files in the `ddl` folder |
# MAGIC | **Outputs** | Schema, volume, tables, views, functions and grants in the internal catalog |
# MAGIC | **Compute** | Serverless, or any cluster with Unity Catalog |
# MAGIC | **Dependencies** | CREATE SCHEMA and CREATE TABLE rights on the internal catalog. MANAGE rights for the grants file |

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Load the settings
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Find the repository folder, read the `env` widget (dev, uat or prod only) and load the config file for that environment, so no name is hardcoded in this notebook. |
# MAGIC | **Input** | Widget `env`, file `config/<env>.yaml` |
# MAGIC | **Output** | `CFG` (all settings), `_repo_root` (repository folder) |

# COMMAND ----------

import glob
import os
import re
import sys

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

from common.config import load_config, sql_placeholders
from common.widgets import env_widget, files_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
print('Settings from', CFG['_path'])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Choose the DDL files to run
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Define how one SQL file is turned into single statements, and pick the files to run. Only names of real files in the `ddl` folder are accepted: any other name stops the run before anything is created. |
# MAGIC | **Input** | Widget `files`, the SQL files in the `ddl` folder |
# MAGIC | **Output** | `paths` (the files to run, in name order), function `statements_of` |

# COMMAND ----------

# Fill the placeholders in one SQL file, remove comments, and split it into single statements
def statements_of(path, values):
    text = open(path, encoding='utf-8').read()
    for placeholder, value in values.items():                         # for example ${catalog} becomes the real catalog
        text = text.replace(placeholder, str(value))
    left = re.findall(r'\$\{[a-z_]+\}', text)                         # any placeholder without a value is an error
    if left:
        raise ValueError(f'{os.path.basename(path)}: no value in the config for {sorted(set(left))}')
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)                  # remove /* block comments */
    text = '\n'.join(line for line in text.splitlines() if not line.strip().startswith('--'))   # remove -- comments
    return [s.strip() for s in re.split(r';\s*(?:\n|$)', text) if s.strip()]


# Every DDL file in the ddl folder, by name without .sql, in name order (01, 02, 03 and so on)
all_paths = {os.path.basename(p).replace('.sql', ''): p
             for p in sorted(glob.glob(os.path.join(_repo_root, 'ddl', '*.sql')))}

# The files to run: ALL, or only the names in the files widget. An unknown name stops the run
paths = [all_paths[name] for name in files_widget(dbutils, list(all_paths))]
print('Files to run:', [os.path.basename(p) for p in paths])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Run the DDL files
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Run every statement, file by file. The run stops at the first error, so no file runs half done without anyone noticing. |
# MAGIC | **Input** | `paths`, placeholder values from the config |
# MAGIC | **Output** | The created or updated objects in the internal catalog, and one line per file in the output |

# COMMAND ----------

values = sql_placeholders(CFG)                           # placeholder values, all from the config
for path in paths:
    statements = statements_of(path, values)
    print(f'{os.path.basename(path)}: {len(statements)} statements')
    for statement in statements:
        spark.sql(statement)                             # a failing statement raises an error and stops the run
print('All DDL files ran successfully')