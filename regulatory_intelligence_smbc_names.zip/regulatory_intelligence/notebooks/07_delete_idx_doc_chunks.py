# Databricks notebook source
# MAGIC %md
# MAGIC # 07_delete_idx_doc_chunks
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Lab cost saving. A Vector Search endpoint has no scale to zero: once it holds an index, it is billed every hour, even when nobody uses the app. Charges stop 24 hours after the last index on the endpoint is deleted. This notebook deletes the index `idx_document_chunks` and, if asked, the endpoint. `04_refresh_idx_doc_chunks` creates them again on its next run (the embeddings are made again, which has a small cost). |
# MAGIC | **Job and task** | None. Run by hand, only in the lab, when testing pauses |
# MAGIC | **Parameters** | `env` (dropdown). `confirm_index` (type the index name, for example idx_document_chunks, to confirm). `delete_endpoint` (no or yes). |
# MAGIC | **Inputs** | `vector_search` block of `config/<env>.yaml`, including `allow_index_delete` |
# MAGIC | **Outputs** | The index deleted, and the endpoint too if asked |
# MAGIC | **Compute** | Serverless |
# MAGIC | **Dependencies** | MANAGE on the index (or ownership), CAN MANAGE on the endpoint to delete it |
# MAGIC
# MAGIC **Safety:** it refuses to run unless the config of the chosen environment says `allow_index_delete: true` (only set in the lab DEV config, never in UAT or PROD), and unless the index name is typed in `confirm_index`.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Install the libraries
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Install the Databricks SDK at the same fixed version as `requirements.txt` (no new library), then restart Python. |
# MAGIC | **Input** | None |
# MAGIC | **Output** | Library `databricks-sdk` 0.164.0 |

# COMMAND ----------

# Fixed version, the same as requirements.txt
%pip install --quiet databricks-sdk==0.164.0
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Load the settings and check the safety rules
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Load the config, then stop unless deleting is allowed in this environment and the index name was typed to confirm. Nothing is deleted in this step. |
# MAGIC | **Input** | Widgets `env`, `confirm_index`, `delete_endpoint`; file `config/<env>.yaml` |
# MAGIC | **Output** | `INDEX_NAME`, `ENDPOINT`, `DELETE_ENDPOINT` |

# COMMAND ----------

import os
import sys

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

from databricks.sdk import WorkspaceClient

from common.config import load_config, table
from common.widgets import env_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
VS = CFG['vector_search']
INDEX_NAME = table(CFG, VS['index'])                     # for example ucaidev.sng_rcm_ai.idx_document_chunks
ENDPOINT = VS['endpoint']                                # for example vs-sng-rcm-devai

# Safety widgets: nothing is deleted unless the index name is typed, and the endpoint stays unless yes is chosen
dbutils.widgets.text('confirm_index', '')
dbutils.widgets.dropdown('delete_endpoint', 'no', ['no', 'yes'])
CONFIRM = dbutils.widgets.get('confirm_index').strip()
DELETE_ENDPOINT = dbutils.widgets.get('delete_endpoint') == 'yes'

# Rule 1: only where the config allows it (the lab DEV config). UAT and PROD configs never allow it
if VS.get('allow_index_delete') is not True:
    raise RuntimeError(f"Deleting the index is not allowed in {CFG['environment']}: "
                       'allow_index_delete is not true in the config.')
# Rule 2: the person must type the index name, so a Run all by mistake deletes nothing
if CONFIRM != VS['index']:
    raise RuntimeError(f"Type {VS['index']} in confirm_index to delete the index. Nothing was deleted.")

print(f'Will delete {INDEX_NAME}' + (f' and the endpoint {ENDPOINT}' if DELETE_ENDPOINT else ''))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Delete the index
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Delete the Vector Search index. The source table `document_chunks` and all other data stay as they are. Endpoint charges stop 24 hours after its last index is deleted. |
# MAGIC | **Input** | `INDEX_NAME` |
# MAGIC | **Output** | The index is deleted (or was already gone) |

# COMMAND ----------

w = WorkspaceClient()
try:
    w.vector_search_indexes.delete_index(INDEX_NAME)
    print(f'Deleted {INDEX_NAME}. The chunk table document_chunks is unchanged.')
except Exception as error:
    print(f'Index not deleted ({type(error).__name__}): it may already be gone.')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Delete the endpoint, only if asked
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Delete the endpoint too, when `delete_endpoint` is yes and no other index uses it. An endpoint with other indexes is never deleted, because other use cases may depend on it. |
# MAGIC | **Input** | `ENDPOINT`, `DELETE_ENDPOINT` |
# MAGIC | **Output** | The endpoint is deleted, or kept with the reason |

# COMMAND ----------

if not DELETE_ENDPOINT:
    print(f'Endpoint {ENDPOINT} kept (delete_endpoint is no). It stops costing 24 hours after its last index is deleted.')
else:
    others = [i.name for i in w.vector_search_indexes.list_indexes(endpoint_name=ENDPOINT) if i.name != INDEX_NAME]
    if others:
        print(f'Endpoint {ENDPOINT} kept: it still serves other indexes {others}.')
    else:
        w.vector_search_endpoints.delete_endpoint(ENDPOINT)
        print(f'Deleted the endpoint {ENDPOINT}. Create it again before the next run of 04_refresh_idx_doc_chunks.')
