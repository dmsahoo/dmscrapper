# Databricks notebook source
# MAGIC %md
# MAGIC # 08_check_vector_search_cost
# MAGIC
# MAGIC | Item | Detail |
# MAGIC |---|---|
# MAGIC | **Purpose** | Shows what Vector Search used per day, split the way the Databricks cost guide does: serving (the endpoint, billed every hour once it holds an index), ingest (the daily triggered sync and its embeddings) and storage. Use it to check that the endpoint is not left running for nothing, and to report the cost of RCM. Reads only the billing system table, changes nothing. |
# MAGIC | **Job and task** | None. Run by hand, for example once a month, in any environment |
# MAGIC | **Parameters** | `env` (dropdown). `days` (how many days back, 1 to 90). |
# MAGIC | **Inputs** | `system.billing.usage`, the endpoint name from `config/<env>.yaml` |
# MAGIC | **Outputs** | Two tables in the notebook output: usage per day, and the total per kind |
# MAGIC | **Compute** | Serverless, or a SQL warehouse |
# MAGIC | **Dependencies** | SELECT on `system.billing.usage` (given by an account or metastore admin) |
# MAGIC
# MAGIC Usage is in DBUs (and DSUs for storage). Multiply by the price of your contract to get the money cost.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Load the settings and read the parameters
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Load the endpoint name from the config, and check `days` (a whole number from 1 to 90). |
# MAGIC | **Input** | Widgets `env`, `days`; file `config/<env>.yaml` |
# MAGIC | **Output** | `ENDPOINT`, `DAYS` |

# COMMAND ----------

import os
import sys

# The repository folder: one level up when this notebook runs from the notebooks folder
_repo_root = os.path.dirname(os.getcwd()) if os.path.basename(os.getcwd()) == 'notebooks' else os.getcwd()
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)                       # so the common folder can be imported

from databricks.sdk import WorkspaceClient

from common.config import load_config
from common.widgets import env_widget, int_widget

CFG = load_config(env_widget(dbutils))                   # dropdown: dev, uat or prod only
ENDPOINT = CFG['vector_search']['endpoint']              # for example vs-sng-rcm-devai
DAYS = int_widget(dbutils, 'days', 30, 1, 90)            # checked whole number, passed as a SQL parameter
print(f'Vector Search usage of {ENDPOINT} for the last {DAYS} days')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Usage per day
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | List the daily usage of Vector Search in this workspace, by kind. Serving rows of other endpoints are left out. Ingest rows have no endpoint name in the billing table, so they are shown for the whole workspace. |
# MAGIC | **Input** | `system.billing.usage`, `ENDPOINT`, `DAYS` |
# MAGIC | **Output** | A table: date, kind, endpoint, DBUs, DSUs |

# COMMAND ----------

# Same classification as the Databricks cost guide: no endpoint name means ingest, STORAGE_SPACE means storage
USAGE_SQL = '''
    WITH usage AS (
        SELECT usage_date,
               usage_metadata.endpoint_name AS endpoint_name,
               CASE WHEN usage_metadata.endpoint_name IS NULL THEN 'ingest'
                    WHEN usage_type = 'STORAGE_SPACE'          THEN 'storage'
                    ELSE 'serving' END                         AS workload_type,
               usage_quantity
        FROM system.billing.usage
        WHERE billing_origin_product = 'VECTOR_SEARCH'
          AND workspace_id = :workspace_id
          AND usage_date >= date_sub(current_date(), :days)
    )
    SELECT usage_date, workload_type, endpoint_name,
           round(sum(CASE WHEN workload_type <> 'storage' THEN usage_quantity END), 2) AS dbus,
           round(sum(CASE WHEN workload_type = 'storage'  THEN usage_quantity END), 2) AS dsus
    FROM usage
    WHERE endpoint_name = :endpoint OR endpoint_name IS NULL      -- this endpoint, plus the workspace ingest
    GROUP BY usage_date, workload_type, endpoint_name
    ORDER BY usage_date DESC, workload_type
'''
# Only this workspace: the billing table holds every workspace of the account
WORKSPACE_ID = str(WorkspaceClient().get_workspace_id())
args = {'workspace_id': WORKSPACE_ID, 'days': DAYS, 'endpoint': ENDPOINT}
daily = spark.sql(USAGE_SQL, args=args)
display(daily)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Total per kind
# MAGIC | | |
# MAGIC |---|---|
# MAGIC | **Purpose** | Add up the period by kind, and count the days the endpoint was billed. If serving shows every day while nobody used the app, delete the index in the lab with `07_delete_idx_doc_chunks`, or move to the shared endpoint in SMBC. |
# MAGIC | **Input** | The daily usage from Step 2 |
# MAGIC | **Output** | A table: kind, days billed, total DBUs, total DSUs |

# COMMAND ----------

daily.createOrReplaceTempView('vs_daily')
display(spark.sql('''
    SELECT workload_type,
           count(DISTINCT usage_date) AS days_billed,
           round(sum(dbus), 2)        AS total_dbus,
           round(sum(dsus), 2)        AS total_dsus
    FROM vs_daily
    GROUP BY workload_type
    ORDER BY workload_type
'''))
