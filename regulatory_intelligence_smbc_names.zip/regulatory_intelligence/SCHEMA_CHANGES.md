# Schema and table name changes for SMBC

Only schema and table names changed. The code structure is the same as in the Deloitte workspace.

## Names

| Before (externaladb.rcm_internal) | After (ucaidev) |
|---|---|
| volume `documents` | `sng_rcm_bronze.vol_regulatory_documents` |
| `rcm_promotion_log` | `sng_rcm_bronze.document_copy_log` |
| `rcm_doc_content` | `sng_rcm_silver.document_content` |
| `rcm_doc_chunk` | `sng_rcm_gold.document_chunks` |
| `rcm_doc_analysis` | `sng_rcm_gold.document_analysis` |
| `rcm_doc_diff` | `sng_rcm_gold.document_diff` |
| `v_app_updates` | `sng_rcm_gold.v_document_analysis_latest` |
| `v_app_history` | `sng_rcm_gold.v_document_analysis_history` |
| `v_app_documents` | `sng_rcm_gold.v_document_content_parsed` |
| `rcm_chunk_embedding` | `sng_rcm_ai.chunk_embeddings` |
| `search_chunks` | `sng_rcm_ai.fn_search_chunks` |
| `get_changes` | `sng_rcm_ai.fn_get_changes` |
| `idx_doc_chunks` | `sng_rcm_ai.idx_document_chunks` |
| `rcm_app_log` | `sng_rcm_ai.app_log` |
| trace tables `rcm_traces_otel_*` | `sng_rcm_ai.traces_otel_*` |
| scraper `ai_platform_dev.regulatory_scraping` | `ucaiextdev.sng_rcm_ai` |

Columns are unchanged. The tool names the model sees (get_changes, search_chunks) are unchanged.

## Files changed

| File | Change |
|---|---|
| `config/dev.yaml` | `catalog: ucaidev`, a `schemas` block (bronze, silver, gold, ai) replacing `schema`, new volume, external catalog and schema, SMBC landing account. Lab values (model service, warehouse, app service principal, guardrail endpoints, credentials) are now `<placeholders>` |
| `common/config.py` | `OBJECTS` lists each object with its layer; `table()` puts each name in its schema; new `schema()`; `volume_path()` uses Bronze; new DDL placeholders |
| `ddl/` | The 12 old files replaced by 12 files grouped by layer, `01_schemas_and_volume` to `12_grants_app` (grants last) |
| `agents/qa_agent.py` | Calls `fn_get_changes` and `fn_search_chunks` |
| `notebooks/05_qa_agent.py`, `app/app.py` | Tools taken from the AI schema |
| `notebooks/06_setup_tracing.py` | Trace tables in the AI schema |
| All notebooks, `app/app.py`, `common/observability.py`, `README.md`, `tests/Queries.py`, `notebooks/test_llm.py` | Old table names replaced by the new ones |

## Removed from the zip

`.git`, the `archive` folders and the dated folder `notebooks/19112026`.

## Not changed (to fix in SMBC)

`os.getcwd`, `sys.path` and `import os` in the notebooks, `common/config.py` and `app/app.py`.

## Checked

`00_run_ddl` ran with a stub Spark: 12 files, 32 statements, no placeholder left. Every name used with
`table()` is known. All Python files compile.
