/* =====================================================================
   01_schemas_and_volume.sql
   The four schemas of the internal workspace (P02 <branch>_<project>_<layer>) and the Bronze volume.
   Placeholders ${...} are filled from config/<env>.yaml by notebooks/00_run_ddl.
   ===================================================================== */

CREATE SCHEMA IF NOT EXISTS ${catalog}.${bronze_schema}
COMMENT 'RCM Bronze: raw copies of the regulatory documents and their copy log';

CREATE SCHEMA IF NOT EXISTS ${catalog}.${silver_schema}
COMMENT 'RCM Silver: extracted text of every document version';

CREATE SCHEMA IF NOT EXISTS ${catalog}.${gold_schema}
COMMENT 'RCM Gold: chunks, CPDAP CPL records, differences and the app views';

CREATE SCHEMA IF NOT EXISTS ${catalog}.${ai_schema}
COMMENT 'RCM AI: embeddings, agent tools, vector index, app log and traces';

CREATE VOLUME IF NOT EXISTS ${catalog}.${bronze_schema}.${volume}
COMMENT 'Documents copied from the external landing storage after the malware scan';
