/* =====================================================================
   04_gold_document_chunks.sql
   document_chunks (Gold, was rcm_doc_chunk): chunks of the CURRENT version of each document.
   Source of the embeddings, the vector index and the document viewer. Change Data Feed is on for the index.
   ===================================================================== */

CREATE TABLE IF NOT EXISTS ${catalog}.${gold_schema}.document_chunks (
    chunk_id             STRING    NOT NULL COMMENT 'document_id, version and chunk number',
    document_id          STRING    NOT NULL,
    version              INT       NOT NULL,
    regulator_id         STRING    NOT NULL,
    chunk_index          INT,
    section_title        STRING,
    page_number          INT       COMMENT 'First page of the chunk (PDF only)',
    chunk_text           STRING,
    char_count           INT,
    file_name            STRING,
    source_url           STRING,
    created_at_sgt       TIMESTAMP,
    CONSTRAINT pk_document_chunks PRIMARY KEY (chunk_id) NOT ENFORCED
)
USING DELTA
COMMENT 'Gold: chunks of the current version of each document, source of the vector index and the search'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
