/* =====================================================================
   03_silver_document_content.sql
   document_content (Silver, was rcm_doc_content): extracted text, one row per document version.
   All versions are kept, so versions can be compared.
   ===================================================================== */

CREATE TABLE IF NOT EXISTS ${catalog}.${silver_schema}.document_content (
    document_id          STRING    NOT NULL,
    version              INT       NOT NULL,
    regulator_id         STRING    NOT NULL,
    content_format       STRING    COMMENT 'PDF or HTML',
    file_name            STRING,
    source_url           STRING,
    internal_file_path   STRING,
    content_text         STRING    COMMENT 'Extracted text. Headings start with ##, tables kept as HTML',
    page_count           INT,
    parse_status         STRING    COMMENT 'PARSED or FAILED',
    parse_error          STRING,
    parsed_at_sgt        TIMESTAMP,
    CONSTRAINT pk_document_content PRIMARY KEY (document_id, version) NOT ENFORCED
)
USING DELTA
COMMENT 'Silver: extracted text per document version';
