/* =====================================================================
   12_grants_app.sql
   Unity Catalog permissions for the app's service principal, in all four schemas.
   ${app_service_principal} is its Application ID, from config/<env>.yaml.
   The model, the SQL warehouse and the secrets are given to the app as resources instead.
   Always runs last, because CREATE OR REPLACE on views and functions removes their grants.
   ===================================================================== */

-- Reach the catalog and the schemas
GRANT USE CATALOG ON CATALOG ${catalog} TO `${app_service_principal}`;
GRANT USE SCHEMA ON SCHEMA ${catalog}.${bronze_schema} TO `${app_service_principal}`;
GRANT USE SCHEMA ON SCHEMA ${catalog}.${silver_schema} TO `${app_service_principal}`;
GRANT USE SCHEMA ON SCHEMA ${catalog}.${gold_schema} TO `${app_service_principal}`;
GRANT USE SCHEMA ON SCHEMA ${catalog}.${ai_schema} TO `${app_service_principal}`;

-- Latest changes tab: the views and the exact wording changes (Gold)
GRANT SELECT ON TABLE ${catalog}.${gold_schema}.v_document_analysis_latest TO `${app_service_principal}`;
GRANT SELECT ON TABLE ${catalog}.${gold_schema}.v_document_analysis_history TO `${app_service_principal}`;
GRANT SELECT ON TABLE ${catalog}.${gold_schema}.document_diff TO `${app_service_principal}`;

-- Document viewer: where each stored document is (Gold view on Silver), the page text (Gold), the files (Bronze)
GRANT SELECT ON TABLE ${catalog}.${gold_schema}.v_document_content_parsed TO `${app_service_principal}`;
GRANT SELECT ON TABLE ${catalog}.${gold_schema}.document_chunks TO `${app_service_principal}`;
GRANT READ VOLUME ON VOLUME ${catalog}.${bronze_schema}.${volume} TO `${app_service_principal}`;

-- AI Assistant tab: the two tools and the table fn_search_chunks reads (AI)
GRANT EXECUTE ON FUNCTION ${catalog}.${ai_schema}.fn_get_changes TO `${app_service_principal}`;
GRANT EXECUTE ON FUNCTION ${catalog}.${ai_schema}.fn_search_chunks TO `${app_service_principal}`;
GRANT SELECT ON TABLE ${catalog}.${ai_schema}.chunk_embeddings TO `${app_service_principal}`;

-- Application log: the app writes and reads its own log lines (AI)
GRANT SELECT, MODIFY ON TABLE ${catalog}.${ai_schema}.app_log TO `${app_service_principal}`;
