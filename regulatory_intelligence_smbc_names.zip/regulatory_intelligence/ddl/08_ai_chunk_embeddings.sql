/* =====================================================================
   08_ai_chunk_embeddings.sql
   chunk_embeddings (AI, was rcm_chunk_embedding): one row per chunk, with its text, the details used for
   filters, and its embedding. Read by fn_search_chunks. Change Data Feed is on.
   ===================================================================== */

CREATE TABLE IF NOT EXISTS ${catalog}.${ai_schema}.chunk_embeddings (
    chunk_id         STRING    NOT NULL,
    document_id      STRING    NOT NULL,
    version          INT       NOT NULL,
    regulator_id     STRING    NOT NULL,
    section_title    STRING,
    chunk_text       STRING    COMMENT 'Used for the keyword part of hybrid search',
    published_date   DATE      COMMENT 'From pdf_catalog.item_date, used for date filters',
    source_url       STRING,
    embedding        ARRAY<FLOAT> COMMENT 'Numbers from the embedding model set in the config',
    embedded_at_sgt  TIMESTAMP
)
USING DELTA
COMMENT 'Source table for the search used by the Q and A Agent'
TBLPROPERTIES (delta.enableChangeDataFeed = true);
