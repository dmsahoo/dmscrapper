/* =====================================================================
   07_gold_views.sql
   v_document_analysis_latest   (was v_app_updates) the Latest changes tab: ONE row per document,
                                its newest validated version.
   v_document_analysis_history  (was v_app_history) every validated version, for Previous versions.
   v_document_content_parsed    (was v_app_documents) where the stored copy of each parsed document version
                                is, so the app can open it when a user clicks a citation. The app looks up the
                                file by document_id and version (both checked), never by a path from a link.
   CREATE OR REPLACE removes grants, so 12_grants_app.sql always runs after this file (00_run_ddl does that).
   ===================================================================== */

CREATE OR REPLACE VIEW ${catalog}.${gold_schema}.v_document_analysis_latest AS
SELECT document_id, regulator_id, version, change_type, event_type, previous_version, what_changed,
       name_of_office, assessment_date, law_or_regulation,
       info_collected_date, source_url, published_date, date_introduced, effective_date,
       intention_background, summary_key_items, areas_of_impact, proposed_action_timeline,
       compliance_risk_category, importance, relevance, relevance_reason, citations, created_at_sgt
FROM ${catalog}.${gold_schema}.document_analysis
WHERE analysis_status = 'VALIDATED'
-- keep only the newest validated version of each document
QUALIFY row_number() OVER (PARTITION BY document_id ORDER BY version DESC) = 1;

CREATE OR REPLACE VIEW ${catalog}.${gold_schema}.v_document_analysis_history AS
SELECT document_id, regulator_id, version, change_type, what_changed, law_or_regulation,
       info_collected_date, published_date, effective_date, source_url, created_at_sgt
FROM ${catalog}.${gold_schema}.document_analysis
WHERE analysis_status = 'VALIDATED';


CREATE OR REPLACE VIEW ${catalog}.${gold_schema}.v_document_content_parsed AS
SELECT document_id, version, regulator_id, file_name, content_format, internal_file_path, page_count,
       content_text                -- full stored text, shown when the page text is not available
FROM ${catalog}.${silver_schema}.document_content
WHERE parse_status = 'PARSED';
