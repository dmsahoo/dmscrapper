# Databricks notebook source
dbutils.fs.rm("/Volumes/ai_platform_dev/regulatory_scraping/raw/MAS", recurse=True)
dbutils.fs.mkdirs("/Volumes/ai_platform_dev/regulatory_scraping/raw/MAS")

# COMMAND ----------

display(spark.sql('DESCRIBE VOLUME ai_platform_dev.regulatory_scraping.raw'))

# COMMAND ----------

# MAGIC %sql
# MAGIC --select count(*) from ai_platform_dev.regulatory_scraping.scraping_audit_log --order by event_time_sgt desc--191
# MAGIC select count(*) from ai_platform_dev.regulatory_scraping.pdf_catalog--54

# COMMAND ----------

# MAGIC %sql
# MAGIC TRUNCATE TABLE ai_platform_dev.regulatory_scraping.scraping_audit_log;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT run_id, record_type, status, skip_reason, count(*) AS rows_written
# MAGIC FROM ai_platform_dev.regulatory_scraping.scraping_audit_log
# MAGIC WHERE event_time_sgt >= '2026-10-13'
# MAGIC GROUP BY ALL
# MAGIC ORDER BY run_id, record_type, status

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT category_id, item_date, item_title, file_name, first_seen_run_id
# MAGIC FROM ai_platform_dev.regulatory_scraping.pdf_catalog
# MAGIC WHERE first_seen_sgt >= '2026-10-13'
# MAGIC ORDER BY category_id, item_date

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE ai_platform_dev.regulatory_scraping.pdf_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ai_platform_dev.regulatory_scraping.pdf_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM ai_platform_dev.regulatory_scraping.pdf_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS documents,
# MAGIC        MIN(item_date) AS oldest,
# MAGIC        MAX(item_date) AS newest,
# MAGIC        SUM(CASE WHEN item_date < '2026-07-10' OR item_date > '2026-10-26' THEN 1 ELSE 0 END) AS outside_period
# MAGIC FROM ai_platform_dev.regulatory_scraping.pdf_catalog
# MAGIC WHERE regulator_id = 'MAS';

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT item_date,
# MAGIC        item_reference,
# MAGIC        item_title,
# MAGIC        COUNT(*)                AS files,
# MAGIC        collect_list(file_name) AS file_names
# MAGIC FROM ai_platform_dev.regulatory_scraping.pdf_catalog
# MAGIC WHERE regulator_id = 'MAS' AND category_id = '1_NOTICES'
# MAGIC GROUP BY item_date, item_reference, item_title
# MAGIC ORDER BY item_date;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT category_id, COUNT(DISTINCT source_url) AS items, COUNT(*) AS files
# MAGIC FROM ai_platform_dev.regulatory_scraping.pdf_catalog
# MAGIC WHERE regulator_id = 'MAS'
# MAGIC GROUP BY category_id ORDER BY category_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT event_time_sgt, record_type, category_id, status, items_found, documents_new, documents_skipped, documents_failed, error_details
# MAGIC FROM ai_platform_dev.regulatory_scraping.scraping_audit_log
# MAGIC WHERE record_type IN ('RUN', 'CATEGORY')
# MAGIC ORDER BY event_time_sgt DESC
# MAGIC LIMIT 12;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Counts per category for the most recent scrape run
# MAGIC SELECT category_id, status, items_found, documents_found, documents_new, documents_changed,
# MAGIC        documents_skipped, documents_failed, error_details
# MAGIC FROM ai_platform_dev.regulatory_scraping.scraping_audit_log
# MAGIC WHERE record_type = 'CATEGORY'
# MAGIC   AND run_id = (SELECT max_by(run_id, event_time_sgt)
# MAGIC                 FROM ai_platform_dev.regulatory_scraping.scraping_audit_log
# MAGIC                 WHERE record_type = 'RUN')
# MAGIC ORDER BY category_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- New documents collected today, per category
# MAGIC SELECT category_id,
# MAGIC        COUNT(DISTINCT source_url) AS items,     -- listing entries (compare with the MAS website)
# MAGIC        COUNT(*)                   AS files      -- documents saved (one entry can have several files)
# MAGIC FROM ai_platform_dev.regulatory_scraping.pdf_catalog
# MAGIC WHERE regulator_id = 'MAS' AND first_seen_sgt >= current_date()
# MAGIC GROUP BY category_id
# MAGIC ORDER BY category_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- The 3 new June documents, with their scan status before the scan verdict job runs
# MAGIC SELECT category_id, item_date, item_title, file_name, content_format, current_version, scrape_status,
# MAGIC        raw_file_path, content_hash_sha256, malware_scan_verdict, scan_timestamp_sgt, first_seen_sgt
# MAGIC FROM ai_platform_dev.regulatory_scraping.pdf_catalog
# MAGIC WHERE regulator_id = 'MAS' AND first_seen_sgt >= current_date()
# MAGIC ORDER BY category_id;