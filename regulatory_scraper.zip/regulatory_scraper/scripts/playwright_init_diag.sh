#!/bin/bash
# DIAGNOSTIC copy of playwright_init.sh (online mode only). For the firewall form, not for production.
# It installs exactly the same things as the real script, and prints every URL it uses.
# Every URL line starts with URL: so the hosts can be extracted from the log with one grep.

set -uo pipefail                                  # no -e: keep going and log, even if one step fails

PLAYWRIGHT_VERSION="${PLAYWRIGHT_VERSION:-1.47.0}"
PIP=/databricks/python3/bin/pip
PY=/databricks/python3/bin/python
LIBS="libgbm1 libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxrandr2 libasound2 libpango-1.0-0 libcairo2"

log() { echo "[diag] $(date '+%Y%m%d %H:%M:%S') $*"; }

# Print the apt repositories (every apt download comes from one of these)
apt_sources() {
    grep -hE '^[[:space:]]*(deb[[:space:]]|URIs:)' /etc/apt/sources.list /etc/apt/sources.list.d/*.list \
        /etc/apt/sources.list.d/*.sources 2>/dev/null | grep -oE 'https?://[^ ]+' | sed 's/^/URL: apt repository /'
}

log "=== 1. apt repositories BEFORE install ==="
apt_sources

log "=== 2. apt-get update (index files) ==="
apt-get update 2>&1 | tee /tmp/apt_update.log
grep -oE 'https?://[^ ]+' /tmp/apt_update.log | sort -u | sed 's/^/URL: apt update /'

log "=== 3. OS libraries: exact .deb URLs, then install ==="
apt-get install -y --print-uris $LIBS | grep -oE "'https?://[^']+'" | tr -d "'" | sed 's/^/URL: apt package /'
apt-get install -y $LIBS

log "=== 4. pip configuration (a custom index changes the hosts) ==="
$PIP config list
env | grep -iE '^(PIP_|HTTPS?_PROXY|NO_PROXY)' || true

log "=== 5. pip install playwright: exact download URLs ==="
$PIP install "playwright==${PLAYWRIGHT_VERSION}" --report /tmp/pip_report.json
$PY - <<'PYEOF'
import json
report = json.load(open('/tmp/pip_report.json'))
for item in report.get('install', []):
    url = (item.get('download_info') or {}).get('url', '')
    print('URL: pip package', url)
PYEOF

log "=== 6. Playwright's Edge install script (shows its own URLs) ==="
SCRIPT=$($PY -c "import playwright, os; print(os.path.join(os.path.dirname(playwright.__file__), 'driver', 'package', 'bin', 'reinstall_msedge_stable_linux.sh'))")
cat "$SCRIPT" || log "Edge install script not found at $SCRIPT"
grep -oE 'https?://[^ "]+' "$SCRIPT" 2>/dev/null | sort -u | sed 's/^/URL: playwright edge script /'

log "=== 7. Playwright dry run ==="
$PY -m playwright install --dry-run msedge

log "=== 8. Install Edge (same command as the real script) ==="
$PY -m playwright install msedge 2>&1 | tee /tmp/edge_install.log
grep -oE 'https?://[^ ]+' /tmp/edge_install.log | sort -u | sed 's/^/URL: edge install /'

log "=== 9. apt repositories AFTER install (the Edge repository should now be listed) ==="
apt_sources

log "=== 10. Result ==="
/usr/bin/microsoft-edge-stable --version || log "Microsoft Edge was not installed"
log "Done"
