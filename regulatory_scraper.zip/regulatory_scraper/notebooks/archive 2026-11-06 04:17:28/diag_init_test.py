# Databricks notebook source
# MAGIC %sh
# MAGIC bash /Workspace/Repos/dipti@deloittetestsggmail.onmicrosoft.com/regulatory_scraper/scripts/playwright_init_diag.sh

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL ai_platform_dev.regulatory_scraping.pdf_catalog;